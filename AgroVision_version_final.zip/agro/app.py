"""AgroVision — interfaz Streamlit para NASA Space Apps Challenge 2026.

Este archivo es la interfaz. Los datos y cálculos viven en integracion.py y la carpeta ml/
(clima CONAGUA, modelo de lluvia, humedad del suelo NASA POWER y planes de rotación).
"""

from __future__ import annotations

import json
import sqlite3
from datetime import date, timedelta
from html import escape
from pathlib import Path

import pandas as pd
import streamlit as st

from contrato import (CAMPOS_CLIMA, EJEMPLO_SALIDA, coordenadas_fuera_de_mexico,
                      construir_entrada, huella)
import almacen
import geo
import mapa
from servicio import ejecutar_analisis

st.set_page_config(
    page_title="AgroVision | Agricultura inteligente",
    page_icon="🌱",
    layout="wide",
    initial_sidebar_state="expanded",
)

CSS_PATH = Path(__file__).parent / "styles.css"


@st.cache_data(show_spinner=False)
def cargar_css(modificado: float) -> str:
    """Se vuelve a leer solo si styles.css cambia (no en cada interacción)."""
    return CSS_PATH.read_text(encoding="utf-8")


st.markdown(f"<style>{cargar_css(CSS_PATH.stat().st_mtime)}</style>", unsafe_allow_html=True)

# ───────────────────────── ESTADO DE LA SESIÓN ─────────────────────────
# Los datos solo viven en esta sesión; NO se guardan en una base de datos.
# estado: sin_ejecutar | sin_algoritmo | ok | demo | error
ESTADO_INICIAL = {
    "pagina": "inicio", "parcela": {}, "resultado": None, "estado": "sin_ejecutar",
    "avisos": [], "error": None, "traza": None, "segundos": None, "huella": None,
    "modo_demo": False, "parcela_id": None,
    "mun_sel": None, "parcela_sel": None, "mapa_epoca": 0, "ultimo_evento": None, "tutorial_visto": False,
}
for _clave, _valor in ESTADO_INICIAL.items():
    st.session_state.setdefault(_clave, _valor)

NOMBRES = {
    "inicio": "Panel principal",
    "tutorial": "Cómo usar",
    "parcela": "Mi parcela",
    "mapa": "Mapa de parcelas",
    "rotacion": "Rotación de cultivos",
    "resultados": "Visión a futuro",
    "fuentes": "Datos NASA",
}
ESTADOS_PAIS = [
    "Aguascalientes", "Baja California", "Baja California Sur", "Campeche", "Chiapas", "Chihuahua",
    "Ciudad de México", "Coahuila", "Colima", "Durango", "Estado de México", "Guanajuato", "Guerrero",
    "Hidalgo", "Jalisco", "Michoacán", "Morelos", "Nayarit", "Nuevo León", "Oaxaca", "Puebla",
    "Querétaro", "Quintana Roo", "San Luis Potosí", "Sinaloa", "Sonora", "Tabasco", "Tamaulipas",
    "Tlaxcala", "Veracruz", "Yucatán", "Zacatecas",
]
CULTIVOS = ["Maíz", "Frijol", "Trigo", "Sorgo", "Cebada", "Avena", "Alfalfa", "Chile", "Jitomate", "Agave", "Otro"]
RIEGOS = ["Temporal (solo lluvia)", "Riego por gravedad", "Riego por goteo", "Riego por aspersión"]
SUELOS = ["No lo sé", "Arcilloso", "Arenoso", "Franco / limoso", "Calcáreo"]
PRIORIDADES = ["Ahorrar agua", "Cuidar el suelo", "Diversificar cultivos", "Equilibrar objetivos"]
# Querétaro (centro aproximado): punto de partida del formulario.
LAT_INICIAL, LON_INICIAL = 20.5888, -100.3899


# ───────────────────────── UTILIDADES ─────────────────────────
def ir_a(pagina: str) -> None:
    st.session_state.pagina = pagina


def seguro(valor: object) -> str:
    """Evita insertar HTML del usuario o del algoritmo en nuestro diseño."""
    return escape(str(valor))


def limpiar_resultado() -> None:
    st.session_state.update(resultado=None, estado="sin_ejecutar", avisos=[], error=None,
                            traza=None, segundos=None, huella=None)


def nueva_parcela() -> None:
    st.session_state.update(parcela={}, parcela_id=None)
    limpiar_resultado()


def marcar_tutorial_visto() -> None:
    st.session_state.tutorial_visto = True


def abrir_tutorial() -> None:
    st.session_state.update(tutorial_visto=True, pagina="tutorial")


def leer_parcelas() -> list[dict]:
    try:
        return almacen.listar()
    except (OSError, sqlite3.Error) as exc:
        st.error(f"No se pudo leer el almacén de parcelas: {exc}")
        return []


def indice(opciones: list[str], valor: object) -> int:
    return opciones.index(valor) if valor in opciones else 0


def encabezado(etiqueta: str, titulo: str, descripcion: str = "") -> None:
    st.markdown(
        f'<div class="page-intro"><div class="eyebrow">{seguro(etiqueta)}</div>'
        f'<h1>{seguro(titulo)}</h1><p>{seguro(descripcion)}</p></div>',
        unsafe_allow_html=True,
    )


def titulo_seccion(etiqueta: str, titulo: str) -> None:
    st.markdown(
        f'<div class="section-heading"><div class="eyebrow">{seguro(etiqueta)}</div>'
        f'<h2>{seguro(titulo)}</h2></div>',
        unsafe_allow_html=True,
    )


def tarjeta_metrica(icono: str, nombre: str, valor: str = "—", nota: str = "Sin conectar") -> None:
    st.markdown(
        f'<div class="metric-card"><div class="metric-top"><span>{seguro(nombre)}</span>'
        f'<span class="metric-icon">{icono}</span></div>'
        f'<div class="metric-number">{seguro(valor)}</div>'
        f'<div class="metric-bottom">{seguro(nota)}</div></div>',
        unsafe_allow_html=True,
    )


def vacio(titulo: str, texto: str, icono: str = "◌") -> None:
    st.markdown(
        f'<div class="empty-state"><div class="empty-icon">{icono}</div>'
        f'<h3>{seguro(titulo)}</h3><p>{seguro(texto)}</p></div>',
        unsafe_allow_html=True,
    )


def es_demo() -> bool:
    return st.session_state.estado == "demo"


# ───────────────────────── ANÁLISIS ─────────────────────────
def correr_analisis() -> None:
    """Llama al algoritmo (con captura de errores) y guarda el resultado en la sesión."""
    parcela = st.session_state.parcela
    with st.spinner("Analizando parcela…"):
        salida = ejecutar_analisis(parcela, demo=st.session_state.modo_demo)
    st.session_state.update(
        estado=salida.estado, resultado=salida.resultado, avisos=salida.avisos, error=salida.error,
        traza=salida.traza, segundos=salida.segundos, huella=huella(parcela),
    )
    if salida.resultado and st.session_state.parcela_id is not None:
        try:
            almacen.guardar_analisis(st.session_state.parcela_id, salida.resultado, demo=salida.estado == "demo")
        except (OSError, sqlite3.Error):
            pass  # el análisis sigue visible en la sesión aunque no se pueda guardar
    st.rerun()  # refresca barra superior, menú y tarjetas con el nuevo estado


def boton_analizar(clave: str) -> None:
    hay_parcela = bool(st.session_state.parcela)
    etiqueta = "Analizar parcela  ↗" if st.session_state.resultado is None else "Volver a analizar  ↻"
    if st.button(etiqueta, key=clave, type="primary", width="stretch", disabled=not hay_parcela,
                 help=None if hay_parcela else "Primero guarda tu parcela en «Mi parcela»."):
        correr_analisis()


def mostrar_estado() -> None:
    """Mensaje claro sobre el último análisis (nunca se inventan resultados)."""
    estado = st.session_state.estado
    if estado == "demo":
        st.markdown('<div class="demo-banner"><strong>MODO DEMOSTRACIÓN</strong> · Los números y textos '
                    'que ves son FICTICIOS y solo sirven para probar el diseño. No son datos de NASA '
                    'ni recomendaciones agrícolas.</div>', unsafe_allow_html=True)
    elif estado == "sin_algoritmo":
        st.info("Todavía no hay un análisis. Registra tu parcela y pulsa «Analizar parcela».")
    elif estado == "error":
        st.error(f"No se pudo completar el análisis: {st.session_state.error}")
        with st.expander("Detalle técnico"):
            st.code(st.session_state.traza or "", language="text")
    elif estado == "ok":
        st.success(f"Visión a futuro lista en {st.session_state.segundos:.1f} s.")

    avisos = st.session_state.avisos
    if avisos:
        with st.expander(f"⚠ {len(avisos)} aviso(s) de validación del formato recibido"):
            for aviso in avisos:
                st.markdown(f"- {aviso}")

    if (st.session_state.huella and st.session_state.parcela
            and huella(st.session_state.parcela) != st.session_state.huella):
        st.warning("La parcela cambió desde el último análisis. Vuelve a analizarla.")


# ───────────────────────── COMPONENTES DE RESULTADOS ─────────────────────────
ICONOS = {"temperatureC": "☀", "rainfallMm": "☂", "soilMoisturePct": "◉", "ndvi": "✳"}


def panel_indicadores(etiqueta_vacia: str) -> None:
    resultado = st.session_state.resultado
    clima = resultado["climate"] if resultado else {}
    if not resultado:
        etiqueta_vacia = "Aún sin analizar"
    for col, clave in zip(st.columns(4), CAMPOS_CLIMA):
        nombre, _, _, _, decimales = CAMPOS_CLIMA[clave]
        indicador = clima.get(clave) or {}
        valor = indicador.get("value")
        with col:
            if valor is None:
                tarjeta_metrica(ICONOS[clave], nombre, "—", etiqueta_vacia)
                continue
            unidad = indicador.get("unit") or ""
            texto = f"{valor:,.{decimales}f}" + (f" {unidad}" if unidad else "")
            partes = [indicador.get("source"), indicador.get("date")]
            if indicador.get("uncertainty") is not None:
                partes.append(f"± {indicador['uncertainty']:g}")
            tarjeta_metrica(ICONOS[clave], nombre, texto, " · ".join(p for p in partes if p) or "Dato de la parcela")


def grafica_series(ayuda_vacia: str) -> None:
    resultado = st.session_state.resultado
    serie = resultado["series"] if resultado else []
    if not serie:
        st.markdown(
            '<div class="chart-empty"><div class="chart-grid"></div>'
            f'<div class="chart-empty-text">▥<br><strong>Sin gráfica todavía</strong><span>{seguro(ayuda_vacia)}</span>'
            '</div></div>',
            unsafe_allow_html=True,
        )
        return
    tabla = pd.DataFrame(serie).set_index("date")
    disponibles = [c for c in CAMPOS_CLIMA if tabla[c].notna().any()]
    pestañas = st.tabs([CAMPOS_CLIMA[c][0] for c in disponibles])
    for pestaña, clave in zip(pestañas, disponibles):
        with pestaña:
            datos = tabla[[clave]].dropna()
            etiqueta = CAMPOS_CLIMA[clave][1]
            (st.bar_chart if clave == "rainfallMm" else st.line_chart)(datos, height=250)
            if etiqueta:
                st.caption(f"Unidad: {etiqueta}")


def bloque_recomendacion(texto_vacio: str) -> None:
    resultado = st.session_state.resultado
    recomendacion = resultado["recommendation"] if resultado else None
    if recomendacion:
        (st.warning if es_demo() else st.success)(recomendacion)
    else:
        vacio("Aún no disponible", texto_vacio, "◎")


def tarjeta_plan(num: int, plan: dict | None) -> None:
    if plan:
        cultivos = " → ".join(plan["crops"])
        extra = (f'<p><strong>{seguro(cultivos)}</strong></p>' if cultivos else "")
        puntaje = f" · {plan['score']:g}/100" if plan.get("score") is not None else ""
        etiqueta = ("EJEMPLO DEMO" if es_demo() else "PROPUESTA DISPONIBLE") + puntaje
        nombre, descripcion = plan["name"], plan["description"]
    else:
        extra, etiqueta = "", "PENDIENTE DE ANÁLISIS"
        nombre, descripcion = "Por definir", "Pulsa «Analizar parcela» para generar esta propuesta."
    st.markdown(
        f'<div class="rotation-card"><div class="rotation-emoji">🌱</div>'
        f'<span class="eyebrow">CICLO {num:02d}</span><h3>{seguro(nombre)}</h3>'
        f'<p>{seguro(descripcion)}</p>{extra}<div class="rotation-tag">{seguro(etiqueta)}</div></div>',
        unsafe_allow_html=True,
    )


# ───────────────────────── MENÚ LATERAL ─────────────────────────
with st.sidebar:
    st.markdown(
        '<div class="brand"><div class="brand-mark">✳</div>'
        '<div><div class="brand-name">Agrovision</div>'
        '<div class="brand-subtitle">EARTH TO FARM</div></div></div>',
        unsafe_allow_html=True,
    )
    st.markdown('<div class="sidebar-label">ESPACIO DE TRABAJO</div>', unsafe_allow_html=True)
    for clave, texto in [
        ("inicio", "▦  Panel principal"), ("tutorial", "?  Cómo usar"), ("parcela", "▧  Mi parcela"),
        ("mapa", "◎  Mapa de parcelas"), ("rotacion", "↻  Rotación de cultivos"), ("resultados", "◈  Visión a futuro"),
        ("fuentes", "◇  Datos NASA"),
    ]:
        st.button(texto, key=f"menu_{clave}", width="stretch",
                  type="primary" if st.session_state.pagina == clave else "secondary",
                  on_click=ir_a, args=(clave,))

    st.caption("AgroVision · Prototipo de hackatón")


# ───────────────────────── BARRA SUPERIOR ─────────────────────────
PILDORAS = {
    "sin_ejecutar": ("", "● &nbsp; LISTO PARA ANALIZAR"),
    "sin_algoritmo": ("", "● &nbsp; LISTO PARA ANALIZAR"),
    "ok": ("", "● &nbsp; DATOS REALES CONECTADOS"),
    "demo": ("warn", "● &nbsp; MODO DEMO · DATOS FICTICIOS"),
    "error": ("err", "● &nbsp; ERROR EN EL ANÁLISIS"),
}
_clase, _texto = PILDORAS[st.session_state.estado]
st.markdown(
    f'<div class="topbar"><span>Mi espacio</span><span class="crumb">/</span>'
    f'<strong>{seguro(NOMBRES[st.session_state.pagina])}</strong>'
    f'<span class="top-status {_clase}">{_texto}</span></div>',
    unsafe_allow_html=True,
)


# ───────────────────────── PANTALLA 1: INICIO ─────────────────────────
def pantalla_inicio() -> None:
    encabezado(
        "NASA SPACE APPS CHALLENGE 2026 · FIELD SHIFT",
        "Tu campo. Un mejor futuro.",
        "Una experiencia sencilla para conocer tu parcela y preparar mejores decisiones agrícolas.",
    )
    st.markdown(
        '<div class="hero"><div class="hero-pill">● &nbsp; AGRICULTURA MÁS RESILIENTE</div>'
        '<h2>El siguiente cultivo empieza<br>con una <em>mejor decisión.</em></h2>'
        '<p>Registra tu parcela y explora cómo se presentarán los análisis y las propuestas de rotación.</p>'
        '<div class="hero-art"><div class="hero-orbit"></div><div class="hero-leaf">✦</div>'
        '<div class="field field-a"></div><div class="field field-b"></div></div></div>',
        unsafe_allow_html=True,
    )
    izq, der, _ = st.columns([1.35, 1.4, 3])
    with izq:
        st.button("Registrar mi parcela  ↗", key="inicio_parcela", type="primary", width="stretch",
                  on_click=ir_a, args=("parcela",))
    with der:
        st.button("Explorar rotaciones  →", key="inicio_rotacion", width="stretch",
                  on_click=ir_a, args=("rotacion",))

    if not st.session_state.tutorial_visto:
        st.markdown('<div class="welcome"><strong>¿Primera vez aquí?</strong> Te explicamos el sitio en 4 pasos '
                    'sencillos, sin tecnicismos.</div>', unsafe_allow_html=True)
        w1, w2, _ = st.columns([1.3, 1.1, 3])
        w1.button("Ver cómo usar la app  →", key="bienvenida_ver", type="primary", width="stretch",
                  on_click=abrir_tutorial)
        w2.button("Ya la conozco", key="bienvenida_cerrar", width="stretch", on_click=marcar_tutorial_visto)

    if es_demo():
        st.write("")
        mostrar_estado()

    titulo_seccion("RESUMEN DE LA PARCELA", "Tu campo en un vistazo")
    panel_indicadores("Sin conectar")

    st.write("")
    izquierda, derecha = st.columns([1.55, 1])
    with izquierda:
        st.markdown('<div class="panel-label">CONDICIONES DE REFERENCIA</div>'
                    '<h3 class="panel-title">Tendencia climática</h3>', unsafe_allow_html=True)
        grafica_series("Pulsa «Analizar parcela» para ver las tendencias.")
    with derecha:
        st.markdown('<div class="panel-label">EVALUACIÓN AGRÍCOLA</div>'
                    '<h3 class="panel-title">Estado de la parcela</h3>', unsafe_allow_html=True)
        bloque_recomendacion("Pulsa «Analizar parcela» para ver la recomendación.")

    titulo_seccion("TU SIGUIENTE PASO", "¿Cómo funciona AgroVision?")
    pasos = [
        ("01", "Registra tu parcela", "Ubicación, cultivo actual, ciclos previos, riego y objetivo."),
        ("02", "Analiza con datos satelitales", "Combina el clima real de CONAGUA, la humedad del suelo de NASA y un modelo de lluvia."),
        ("03", "Visualiza alternativas", "La visión a futuro, las tendencias y las rotaciones aparecen en estas pantallas."),
    ]
    for columna, (numero, nombre, detalle) in zip(st.columns(3), pasos):
        with columna:
            st.markdown(
                f'<div class="step-card"><span class="step-number">{numero}</span>'
                f'<h3>{seguro(nombre)}</h3><p>{seguro(detalle)}</p></div>',
                unsafe_allow_html=True,
            )
    st.markdown('<div class="note">ℹ &nbsp; <strong>Frontend únicamente:</strong> esta versión no usa datos '
                'reales de NASA ni calcula recomendaciones por sí misma.</div>', unsafe_allow_html=True)


# ───────────────────────── PANTALLA: CÓMO USAR (TUTORIAL) ─────────────────────────
def pantalla_tutorial() -> None:
    marcar_tutorial_visto()
    encabezado("GUÍA RÁPIDA", "Cómo usar AgroVision.",
               "Cuatro pasos sencillos. Si algo no se entiende, aquí abajo hay un glosario y preguntas frecuentes.")

    pasos = [
        ("01", "Registra tu parcela", "Escribe un nombre, elige tu estado y cultivo, y anota la ubicación. "
         "Tip: en Google Maps toca y mantén sobre tu parcela y copia los dos números que aparecen (latitud y longitud).",
         "Ir a Mi parcela", "parcela"),
        ("02", "Pide el análisis", "En «Mi parcela» pulsa «Analizar parcela». La app revisa el clima, "
         "el agua en la tierra y qué tan sano está el cultivo.", "Ir a Visión a futuro", "resultados"),
        ("03", "Lee tu visión a futuro", "Cada tarjeta muestra un dato con su unidad y de dónde viene. "
         "Si ves «—», todavía no hay dato. Abajo aparecen las rotaciones de cultivo sugeridas.",
         "Ver rotaciones", "rotacion"),
        ("04", "Explora el mapa", "Toca un municipio para acercarte y ver cuántas parcelas hay y cómo están. "
         "Es una forma de compararte con tu zona.", "Abrir el mapa", "mapa"),
    ]
    for fila in (pasos[:2], pasos[2:]):
        for col, (num, nombre, detalle, boton, destino) in zip(st.columns(2), fila):
            with col:
                st.markdown(f'<div class="step-card" style="min-height:190px"><span class="step-number">{num}</span>'
                            f'<h3>{seguro(nombre)}</h3><p>{seguro(detalle)}</p></div>', unsafe_allow_html=True)
                st.button(boton + "  →", key=f"tut_{num}", on_click=ir_a, args=(destino,))
        st.write("")

    titulo_seccion("EN PALABRAS SIMPLES", "¿Qué significa cada dato?")
    glosario = [
        ("☀", "Temperatura (°C)", "Qué tan caliente o fría estuvo la zona. Muy alta o muy baja puede dañar el cultivo."),
        ("☂", "Precipitación (mm)", "Cuánta lluvia cayó. 1 mm equivale a 1 litro de agua por cada metro cuadrado."),
        ("◉", "Humedad del suelo (%)", "Cuánta agua hay en la tierra. Si es muy baja, la planta puede pasar sed."),
        ("✳", "Vigor vegetal (NDVI)", "Qué tan verde y sano se ve el cultivo desde el satélite. Va de -1 a 1: "
         "mientras más cerca de 1, más vigoroso."),
    ]
    for col, (icono, nombre, texto) in zip(st.columns(4), glosario):
        with col:
            st.markdown(f'<div class="source-card" style="min-height:190px"><div class="source-icon">{icono}</div>'
                        f'<h3 style="font-size:15px">{seguro(nombre)}</h3><p>{seguro(texto)}</p></div>',
                        unsafe_allow_html=True)

    titulo_seccion("DUDAS COMUNES", "Preguntas frecuentes")
    preguntas = [
        ("¿Por qué veo «—» o «Pendiente»?",
         "Significa que ese dato todavía no está disponible: o no has pulsado «Analizar parcela», o el sistema "
         "de análisis no tiene datos para tu zona (por ejemplo NDVI, que no está conectado). La app nunca inventa números."),
        ("¿Dónde se guardan mis datos?",
         "Las parcelas se guardan en el equipo donde corre la aplicación. El mapa muestra las parcelas guardadas ahí; "
         "pide permiso a cada productor antes de mostrar su ubicación en público."),
        ("¿El municipio no coincide con el que escribí?",
         "El mapa ubica cada parcela por sus coordenadas. Revisa que la latitud y la longitud estén bien "
         "(en México la longitud es negativa, por ejemplo -100.39)."),
        ("¿La visión a futuro es una orden de qué sembrar?",
         "No. Son una ayuda para decidir mejor. Para decisiones importantes conviene consultarlas con un técnico agrícola."),
    ]
    for pregunta, respuesta in preguntas:
        with st.expander(pregunta):
            st.write(respuesta)

    st.write("")
    st.button("Empezar: registrar mi parcela  ↗", key="tut_empezar", type="primary", on_click=ir_a, args=("parcela",))


# ───────────────────────── PANTALLA 2: MI PARCELA ─────────────────────────
def pantalla_parcela() -> None:
    encabezado(
        "CONFIGURACIÓN · PASO 01",
        "Conoce tu parcela.",
        "Completa el formulario. Los datos que escribas se guardarán temporalmente en esta sesión.",
    )
    guardada = st.session_state.parcela
    st.markdown('<div class="form-intro"><strong>Información del terreno</strong>'
                '<span>La ubicación (latitud y longitud) es necesaria para consultar datos satelitales.</span></div>',
                unsafe_allow_html=True)
    hoy = date.today()
    periodo_previo = (date.fromisoformat(guardada["periodo_inicio"]), date.fromisoformat(guardada["periodo_fin"])) \
        if guardada else (hoy - timedelta(days=365), hoy)

    props = geo.propiedades()   # solo los municipios con estación CONAGUA (geo.ZONA_CVE)
    nombres_mun = [p["nombre"] for p in props.values()]
    previo_mun = (geo.por_nombre(guardada.get("municipio")) or {}).get("nombre") if guardada else None
    municipio = st.selectbox(
        "Municipio (zona cubierta con datos de estaciones CONAGUA)", nombres_mun,
        index=nombres_mun.index(previo_mun) if previo_mun in nombres_mun else 0, key="form_municipio",
        help="La página tiene datos climáticos reales solo de estos municipios. Al cambiarlo, la ubicación se centra en él.")
    mun = geo.por_nombre(municipio)
    # Misma parcela y mismo municipio -> conserva sus coordenadas; si cambia el municipio, se centra en él.
    mismo = bool(guardada) and previo_mun == municipio
    lat_ini = float(guardada["latitud"]) if mismo else float(mun["lat"])
    lon_ini = float(guardada["longitud"]) if mismo else float(mun["lon"])

    with st.form("formulario_parcela"):
        left, right = st.columns(2)
        with left:
            nombre = st.text_input("Nombre de la parcela", value=guardada.get("nombre", ""),
                                   placeholder="Ej. Parcela Los Pinos", max_chars=80)
            region = geo.ESTADO
            st.text_input("Estado", value=geo.ESTADO, disabled=True)
            c1, c2 = st.columns(2)
            latitud = c1.number_input("Latitud (°)", min_value=-90.0, max_value=90.0, format="%.5f", step=0.001,
                                      value=lat_ini, key=f"lat_{mun['cve']}_{int(mismo)}",
                                      help="Grados decimales. En Google Maps: clic derecho sobre tu parcela.")
            longitud = c2.number_input("Longitud (°)", min_value=-180.0, max_value=180.0, format="%.5f", step=0.001,
                                       value=lon_ini, key=f"lon_{mun['cve']}_{int(mismo)}",
                                       help="En México es negativa (ej. -100.39).")
            periodo = st.date_input("Periodo de análisis", value=periodo_previo, max_value=hoy,
                                    help="Rango de fechas de los datos climáticos que se analizarán.")
        with right:
            cultivo = st.selectbox("Cultivo actual", CULTIVOS, index=indice(CULTIVOS, guardada.get("cultivo")))
            previos = st.multiselect("Cultivos de los últimos ciclos", CULTIVOS,
                                     default=[c for c in guardada.get("cultivos_previos", []) if c in CULTIVOS],
                                     help="Sirve para proponer una rotación que no repita el mismo cultivo.")
            area = st.number_input("Superficie (hectáreas)", min_value=0.1, max_value=10_000.0,
                                   value=float(guardada.get("hectareas", 1.0)), step=0.5,
                                   help="Una parcela típica tiene entre 1 y 50 ha.")
            riego = st.selectbox("Tipo de riego", RIEGOS, index=indice(RIEGOS, guardada.get("tipo_riego")))
            suelo = st.selectbox("Tipo de suelo (si lo conoces)", SUELOS,
                                 index=indice(SUELOS, guardada.get("tipo_suelo") or "No lo sé"))
            prioridad = st.selectbox("Objetivo principal", PRIORIDADES,
                                     index=indice(PRIORIDADES, guardada.get("prioridad")))

        observaciones = st.text_area("Notas opcionales", value=guardada.get("observaciones", ""), height=90,
                                     placeholder="Información adicional sobre tu terreno (opcional)", max_chars=1000)
        guardo = st.form_submit_button("Guardar información de la parcela  ✓", type="primary", width="stretch")

    if guardo:
        if not (isinstance(periodo, (tuple, list)) and len(periodo) == 2):
            st.error("Selecciona una fecha de inicio y una de fin en el periodo de análisis.")
        elif geo.municipio_en(latitud, longitud) is None:
            st.error("Esas coordenadas quedan fuera de los municipios cubiertos (" + ", ".join(nombres_mun) +
                     "). Ajusta la latitud y longitud o elige otro municipio.")
        else:
            detectado = geo.municipio_en(latitud, longitud)
            if area > 500:
                st.warning(f"Indicaste {area:,.0f} ha: es una superficie muy grande para una parcela. Revisa que no sea un error.")
            nueva = {
                "nombre": nombre.strip() or "Mi parcela", "region": region,
                "municipio": detectado["nombre"],
                "latitud": round(latitud, 5), "longitud": round(longitud, 5),
                "cultivo": cultivo, "cultivos_previos": previos, "hectareas": area,
                "tipo_riego": riego, "tipo_suelo": None if suelo == "No lo sé" else suelo,
                "prioridad": prioridad, "periodo_inicio": periodo[0].isoformat(),
                "periodo_fin": periodo[1].isoformat(), "observaciones": observaciones.strip(),
            }
            if nueva != guardada:
                limpiar_resultado()  # un resultado viejo no debe mostrarse con una parcela nueva
            st.session_state.parcela = nueva
            try:
                st.session_state.parcela_id = almacen.guardar_parcela(nueva, st.session_state.parcela_id)
                st.success("¡Parcela guardada! Ya aparece en el mapa y puedes analizarla.")
            except (OSError, sqlite3.Error) as exc:
                st.success("¡Parcela guardada en esta sesión! Ya puedes analizarla.")
                st.warning(f"No se pudo guardar de forma permanente (no aparecerá en el mapa): {exc}")
            if coordenadas_fuera_de_mexico(latitud, longitud):
                st.warning("Las coordenadas parecen estar fuera de México. Revisa que la longitud sea negativa.")

    datos = st.session_state.parcela
    if not datos:
        return
    titulo_seccion("VISTA PREVIA", "Información que capturó la página")
    mapa, resumen = st.columns([1, 1.2])
    with mapa:
        st.map(pd.DataFrame({"lat": [datos["latitud"]], "lon": [datos["longitud"]]}), zoom=9, height=230)
    with resumen:
        previos_txt = ", ".join(datos["cultivos_previos"]) or "No indicados"
        st.markdown(
            f'<div class="saved-summary"><h3>🌾 {seguro(datos["nombre"])}</h3>'
            f'<p><strong>Ubicación:</strong> {seguro(datos["region"])} · {seguro(datos["municipio"] or "No indicada")} '
            f'({datos["latitud"]:.4f}, {datos["longitud"]:.4f})</p>'
            f'<p><strong>Cultivo:</strong> {seguro(datos["cultivo"])} &nbsp;·&nbsp; '
            f'<strong>Previos:</strong> {seguro(previos_txt)}</p>'
            f'<p><strong>Superficie:</strong> {seguro(datos["hectareas"])} ha &nbsp;·&nbsp; '
            f'<strong>Riego:</strong> {seguro(datos["tipo_riego"])}</p>'
            f'<p><strong>Objetivo:</strong> {seguro(datos["prioridad"])} &nbsp;·&nbsp; '
            f'<strong>Periodo:</strong> {seguro(datos["periodo_inicio"])} a {seguro(datos["periodo_fin"])}</p></div>',
            unsafe_allow_html=True,
        )
    detectado = geo.municipio_en(datos["latitud"], datos["longitud"])
    st.caption(f"📍 Según las coordenadas, la parcela está en el municipio de {detectado['nombre']}, {geo.ESTADO}."
               if detectado else "📍 Las coordenadas están fuera de los límites municipales de Querétaro "
               "(no se contará en ningún municipio del mapa).")
    a, b, c, _ = st.columns([1.3, 1.5, 1.6, 1])
    with a:
        st.button("Ver visión a futuro  →", key="parcela_ver", width="stretch", on_click=ir_a, args=("resultados",))
    with b:
        boton_analizar("parcela_analizar")
    with c:
        st.button("＋ Registrar otra parcela", key="parcela_nueva", width="stretch", on_click=nueva_parcela)
    mostrar_estado()


# ───────────────────────── PANTALLA: MAPA DE PARCELAS ─────────────────────────
TODO_ESTADO = "Todo Querétaro"


def elegir_municipio(cve: str | None, remontar: bool = True) -> None:
    """Cambia el municipio elegido. Con remontar=False el mapa se conserva y la cámara se desliza
    (así el terreno «se levanta» con animación); con True se redibuja desde cero."""
    st.session_state.update(mun_sel=cve, parcela_sel=None)
    if remontar:
        st.session_state.update(mapa_epoca=st.session_state.mapa_epoca + 1, ultimo_evento=None)


def elegir_parcela(parcela_id: int | None, activas: pd.DataFrame) -> None:
    """Enfoca una parcela desde el buscador: elige también su municipio."""
    if parcela_id is None:
        st.session_state.update(parcela_sel=None, mapa_epoca=st.session_state.mapa_epoca + 1, ultimo_evento=None)
        return
    fila = activas[activas["id"] == parcela_id]
    if fila.empty:
        return
    cve = fila.iloc[0]["mun_cve"]
    st.session_state.update(mun_sel=cve if pd.notna(cve) else None, parcela_sel=int(parcela_id),
                            mapa_epoca=st.session_state.mapa_epoca + 1, ultimo_evento=None)


def elegir_desde_selector() -> None:
    nombre = st.session_state.mapa_selector
    elegir_municipio(next((c for c, p in geo.propiedades().items() if p["nombre"] == nombre), None))


def pantalla_mapa() -> None:
    encabezado(
        "MONITOREO · COMUNIDAD",
        "Mapa de Querétaro.",
        "Haz clic en un municipio para acercarte y ver sus parcelas e indicadores.",
    )
    with st.expander("¿Cómo se usa este mapa?", expanded=not st.session_state.tutorial_visto):
        st.markdown(
            "1. **Toca un municipio**: el mapa se acerca y el terreno «se levanta».\n"
            "2. **Pasa el cursor** sobre un municipio o una parcela para ver sus datos.\n"
            "3. **Panel de la derecha**: muestra la información del municipio y sus parcelas.\n"
            "4. **«← Todo Querétaro»** te regresa a la vista completa.\n\n"
            "También puedes elegir el municipio de la lista si prefieres no tocar el mapa.")
        st.button("Ver el tutorial completo", key="mapa_tutorial", on_click=abrir_tutorial)
    parcelas = leer_parcelas()
    with st.expander("Datos de ejemplo para probar el mapa", expanded=not parcelas):
        st.caption("Crea parcelas FICTICIAS dentro de los municipios (con indicadores inventados) para ver cómo "
                   "luce el mapa. Se marcan como «EJEMPLO» y se pueden borrar en cualquier momento.")
        b1, b2, _ = st.columns([1.3, 1.3, 2.5])
        if b1.button("Cargar ejemplos", key="mapa_cargar_ej", width="stretch"):
            almacen.cargar_ejemplos()
            st.rerun()
        if b2.button("Borrar ejemplos", key="mapa_borrar_ej", width="stretch"):
            almacen.borrar_ejemplos()
            elegir_municipio(None)
            st.rerun()
    if not parcelas:
        vacio("Aún no hay parcelas registradas",
              "Registra una en «Mi parcela» o carga los datos de ejemplo.", "◎")
        return

    props = geo.propiedades()
    cve_sel = st.session_state.mun_sel
    parcela_sel = st.session_state.parcela_sel
    df = mapa.dataframe(parcelas)

    # ── Controles (el selector es la alternativa al clic y siempre está sincronizado con él)
    st.markdown('<div class="map-toolbar-hint">🖱️ <b>Explora el mapa:</b> arrastra para moverte, usa la rueda para '
                'acercarte y haz clic en un municipio o parcela para ver sus detalles.</div>', unsafe_allow_html=True)
    activas = df[df["activa"]]
    st.session_state["mapa_selector"] = props[cve_sel]["nombre"] if cve_sel else TODO_ESTADO
    c1, c2, c3 = st.columns([1.7, 1.7, 1])
    c1.selectbox("🔎 Buscar municipio", [TODO_ESTADO] + sorted(p["nombre"] for p in props.values()),
                 key="mapa_selector", on_change=elegir_desde_selector)
    ids = [None] + [int(i) for i in activas["id"]]
    nombres = {int(r.id): f"{r.nombre} · {r.municipio} ({r.cultivo})" for r in activas.itertuples()}
    # La clave cambia con la selección para que la lista siempre muestre la parcela actual.
    buscada = c2.selectbox("📍 Buscar parcela", ids, index=ids.index(parcela_sel) if parcela_sel in ids else 0,
                           format_func=lambda i: "Todas las parcelas" if i is None else nombres[i],
                           key=f"mapa_buscar_{st.session_state.mapa_epoca}_{parcela_sel}")
    if buscada != parcela_sel:
        elegir_parcela(buscada, activas)
        st.rerun()
    estilo = c3.segmented_control("Estilo del mapa", ["Claro", "Oscuro"], default="Claro", key="mapa_estilo")

    c4, c5, c6, c7, c8 = st.columns([1.5, 1.1, 0.9, 0.9, 1])
    metrica = c4.selectbox("Colorear municipios por", list(mapa.METRICAS), key="mapa_metrica",
                           format_func=lambda m: mapa.METRICAS[m])
    cultivo = c5.selectbox("Filtrar cultivo", ["Todos"] + sorted(df["cultivo"].dropna().unique()), key="mapa_cultivo")
    etiquetas = c6.toggle("Nombres", value=True, key="mapa_etiquetas",
                          help="Desactívalo para un mapa más limpio y rápido.")
    ver_todas = c7.toggle("Ver parcelas", value=False, key="mapa_ver_parcelas",
                          help="En la vista del estado se ocultan para ver mejor los municipios. Al acercarte a un municipio se muestran siempre.")
    mostrar = ver_todas or cve_sel is not None
    with c8:
        st.write("")
        st.button("← Todo Querétaro", key="mapa_volver", width="stretch",
                  disabled=cve_sel is None and parcela_sel is None, on_click=elegir_municipio, args=(None,))

    if cultivo != "Todos":
        activas = activas[activas["cultivo"] == cultivo]
    metricas = mapa.metricas_municipios(activas)
    ambito = activas[activas["mun_cve"] == cve_sel] if cve_sel else activas

    # ── Indicadores del ámbito actual (estado o municipio)
    k = st.columns(4)
    with k[0]:
        tarjeta_metrica("◎", "Parcelas activas", str(len(ambito)),
                        props[cve_sel]["nombre"] if cve_sel else "En todo el estado")
    with k[1]:
        tarjeta_metrica("▧", "Superficie activa", f"{ambito['hectareas'].sum():,.1f} ha", "Suma de parcelas activas")
    with k[2]:
        if cve_sel:
            tarjeta_metrica("▦", "Área del municipio", f"≈ {props[cve_sel]['area_km2']:,.0f} km²", "Aproximada")
        else:
            tarjeta_metrica("▦", "Municipios con parcelas", f"{int((metricas['parcelas'] > 0).sum())} / {len(props)}",
                            "Con al menos una activa")
    with k[3]:
        con_dato = int(ambito[list(CAMPOS_CLIMA)].notna().any(axis=1).sum())
        tarjeta_metrica("✳", "Con indicadores", f"{con_dato} / {len(ambito)}", "Parcelas con análisis")
    if activas["ejemplo"].any() or activas["analisis_demo"].any():
        st.markdown('<div class="demo-banner" style="margin-top:14px"><strong>Hay datos de ejemplo o demostración</strong> '
                    'en el mapa (parcelas «EJEMPLO» o indicadores ficticios). No son mediciones reales.</div>',
                    unsafe_allow_html=True)
    fuera = int(activas["mun_cve"].isna().sum())
    if fuera:
        st.caption(f"{fuera} parcela(s) activa(s) están fuera de los límites de Querétaro: aparecen como puntos, "
                   "pero no suman a ningún municipio.")

    # ── Mapa + ficha
    st.write("")
    izq, der = st.columns([2.2, 1])
    with izq:
        deck = mapa.construir(activas, metricas, metrica, cve_sel, parcela_sel, mostrar,
                              estilo=estilo, mostrar_etiquetas=etiquetas)
        evento = st.pydeck_chart(deck, height=560, on_select="rerun", selection_mode="single-object",
                                 key=f"mapa_deck_{st.session_state.mapa_epoca}")
        st.markdown(mapa.leyenda_html(metrica, mapa.rango_metrica(metricas, metrica)), unsafe_allow_html=True)
        if mostrar and not activas.empty:
            paleta = mapa.color_cultivos(list(activas["cultivo"].dropna()))
            chips = "".join(
                f'<span style="display:inline-flex;align-items:center;gap:5px;margin-right:12px;font-size:12px;'
                f'color:#526b5a"><i style="width:10px;height:10px;border-radius:50%;background:rgb{rgb}"></i>'
                f'{seguro(c)}</span>' for c, rgb in paleta.items())
            st.markdown(f'<div style="margin-top:4px">Parcelas por cultivo: {chips}</div>', unsafe_allow_html=True)

        # Clic en el mapa → cambia la selección y la cámara se acerca (la app se vuelve a dibujar).
        nuevo_cve, nueva_parcela = mapa.leer_seleccion(evento)
        firma = (nuevo_cve, nueva_parcela)
        if firma != (None, None) and firma != st.session_state.ultimo_evento:  # solo clics nuevos
            st.session_state.ultimo_evento = firma
            if nuevo_cve and nuevo_cve != cve_sel:
                elegir_municipio(nuevo_cve, remontar=False)
                st.rerun()
            if nueva_parcela and nueva_parcela != parcela_sel:
                fila = activas[activas["id"] == nueva_parcela]
                if not fila.empty and fila.iloc[0]["mun_cve"] and fila.iloc[0]["mun_cve"] != cve_sel:
                    elegir_municipio(fila.iloc[0]["mun_cve"], remontar=False)
                st.session_state.parcela_sel = nueva_parcela
                st.rerun()
    with der:
        _ficha(cve_sel, metricas, ambito, props)

    # ── Detalle debajo del mapa
    if cve_sel:
        elegida = ambito[ambito["id"] == parcela_sel]
        if not elegida.empty:
            fila = elegida.iloc[0]
            titulo_seccion("PARCELA SELECCIONADA", str(fila["nombre"]))
            nota = f"{fila['cultivo']} · {fila['hectareas']:g} ha" + (" · EJEMPLO" if fila["ejemplo"] else "")
            origen = fila
        else:
            titulo_seccion("PROMEDIO DEL MUNICIPIO", props[cve_sel]["nombre"])
            nota = f"Promedio de {len(ambito)} parcela(s) activa(s)"
            origen = metricas.loc[cve_sel]
        for col, campo in zip(st.columns(4), CAMPOS_CLIMA):
            nombre, unidad, *_resto, decimales = CAMPOS_CLIMA[campo]
            valor = origen[campo]
            with col:
                tarjeta_metrica(ICONOS[campo], nombre,
                                f"{valor:.{decimales}f} {unidad}".strip() if pd.notna(valor) else "—", nota)

    if not activas.empty:  # exporta lo que está filtrado en el mapa
        st.download_button("⬇ Descargar parcelas visibles (CSV)",
                           activas[["nombre", "municipio", "lat", "lon", "cultivo", "hectareas", "activa", "ejemplo"]]
                           .to_csv(index=False).encode("utf-8-sig"),
                           file_name="agrovision_parcelas_mapa.csv", mime="text/csv", key="mapa_exportar")

    with st.expander("Administrar parcelas (activar / desactivar)"):
        editable = df[["id", "nombre", "municipio", "cultivo", "hectareas", "activa", "ejemplo"]].copy()
        editado = st.data_editor(
            editable, key="mapa_editor", hide_index=True, width="stretch",
            disabled=["id", "nombre", "municipio", "cultivo", "hectareas", "ejemplo"],
            column_config={"activa": st.column_config.CheckboxColumn("Activa"),
                           "hectareas": st.column_config.NumberColumn("Hectáreas", format="%.1f"),
                           "ejemplo": st.column_config.CheckboxColumn("Ejemplo")})
        cambios = editado[editado["activa"] != editable["activa"]]
        if not cambios.empty:
            for fila in cambios.itertuples():
                almacen.cambiar_activa(int(fila.id), bool(fila.activa))
            st.rerun()
        st.caption("Una parcela inactiva no se cuenta ni se dibuja en el mapa.")


def _ficha(cve_sel: str | None, metricas: pd.DataFrame, ambito: pd.DataFrame, props: dict) -> None:
    """Panel de información: resumen estatal (con ranking clicable) o ficha del municipio elegido."""
    epoca = st.session_state.mapa_epoca
    if not cve_sel:
        st.markdown(
            f'<div class="muni-card"><div class="muni-eyebrow">ESTADO · {len(props)} MUNICIPIOS</div>'
            f'<h3>{seguro(geo.ESTADO)}</h3><p>Elige un municipio en el mapa o en la lista para acercarte.</p></div>',
            unsafe_allow_html=True)
        ranking = metricas.sort_values(["parcelas", "hectareas"], ascending=False).reset_index()
        tope = max(int(ranking["parcelas"].max()), 1)
        evento = st.dataframe(
            ranking[["nombre", "parcelas", "hectareas"]], hide_index=True, width="stretch", height=420,
            on_select="rerun", selection_mode="single-row", key=f"mapa_ranking_{epoca}",
            column_config={"nombre": "Municipio",
                           "parcelas": st.column_config.ProgressColumn("Parcelas", min_value=0, max_value=tope,
                                                                       format="%d"),
                           "hectareas": st.column_config.NumberColumn("Hectáreas", format="%.1f")})
        filas = evento.selection.rows
        if filas:
            elegir_municipio(ranking.iloc[filas[0]]["cve"])
            st.rerun()
        return

    p = props[cve_sel]
    fila = metricas.loc[cve_sel]
    st.markdown(
        f'<div class="muni-card"><div class="muni-eyebrow">MUNICIPIO · CLAVE 22{seguro(cve_sel)}</div>'
        f'<h3>{seguro(p["nombre"])}</h3>'
        f'<div class="muni-stats"><div><b>{int(fila["parcelas"])}</b><span>parcelas activas</span></div>'
        f'<div><b>{fila["hectareas"]:g}</b><span>hectáreas</span></div>'
        f'<div><b>≈{p["area_km2"]:,.0f}</b><span>km² del municipio</span></div></div></div>',
        unsafe_allow_html=True)
    if ambito.empty:
        vacio("Sin parcelas activas aquí", "Registra una parcela con coordenadas dentro de este municipio.", "◎")
        return
    st.markdown('<div class="panel-label">CULTIVOS</div>', unsafe_allow_html=True)
    st.bar_chart(ambito.groupby("cultivo")["hectareas"].sum().rename("Hectáreas"), horizontal=True, height=170,
                color="#32805a")
    st.markdown('<div class="panel-label">PARCELAS (clic en una fila para resaltarla)</div>', unsafe_allow_html=True)
    tabla = ambito[["id", "nombre", "cultivo", "hectareas"]].reset_index(drop=True)
    evento = st.dataframe(tabla[["nombre", "cultivo", "hectareas"]], hide_index=True, width="stretch", height=min(38 + 35 * len(tabla), 250),
                          on_select="rerun", selection_mode="single-row", key=f"mapa_parcelas_{cve_sel}_{epoca}",
                          column_config={"nombre": "Parcela", "cultivo": "Cultivo",
                                         "hectareas": st.column_config.NumberColumn("ha", format="%.1f")})
    filas = evento.selection.rows
    if filas and int(tabla.iloc[filas[0]]["id"]) != st.session_state.parcela_sel:
        st.session_state.parcela_sel = int(tabla.iloc[filas[0]]["id"])
        st.rerun()


# ───────────────────────── PANTALLA 3: ROTACIÓN ─────────────────────────
def pantalla_rotacion() -> None:
    encabezado(
        "PLANIFICACIÓN · PASO 02",
        "Rotación de cultivos.",
        "Propuestas calculadas con el clima real de la estación CONAGUA más cercana y reglas agronómicas.",
    )
    mostrar_estado()
    titulo_seccion("PLAN DEL SIGUIENTE CICLO", "Alternativas de rotación")
    resultado = st.session_state.resultado
    planes = resultado["plans"] if resultado else []
    total = max(3, len(planes))
    for inicio in range(0, total, 3):  # se muestran TODOS los planes, de 3 en 3
        for col, num in zip(st.columns(3), range(inicio + 1, inicio + 4)):
            with col:
                if num <= total:
                    tarjeta_plan(num, planes[num - 1] if num <= len(planes) else None)
    st.write("")
    if not planes:
        vacio("Comparación de estrategias", "Registra tu parcela y pulsa «Analizar parcela» para calcular las alternativas de rotación.", "↻")
    st.button("Volver a Mi parcela  →", key="rotacion_parcela", on_click=ir_a, args=("parcela",))


# ───────────────────────── PANTALLA 4: RESULTADOS ─────────────────────────
def pantalla_resultados() -> None:
    encabezado(
        "VISIÓN A FUTURO · PASO 03",
        "Análisis de tu campo.",
        "Clima real de la estación CONAGUA, humedad del suelo de NASA y rotaciones sugeridas.",
    )
    datos = st.session_state.parcela
    if not datos:
        st.warning("Todavía no has registrado una parcela. Puedes ver el diseño, pero conviene llenar el formulario.")
        st.button("Ir a Mi parcela  →", key="resultados_parcela", on_click=ir_a, args=("parcela",))
    else:
        st.markdown(
            f'<div class="summary-strip"><span>PARCELA ACTUAL</span><strong>{seguro(datos["nombre"])}</strong>'
            f'<span>{seguro(datos["region"])} · {seguro(datos["cultivo"])}</span></div>',
            unsafe_allow_html=True,
        )
        st.write("")
        a, b, _ = st.columns([1.3, 1.3, 3])
        with a:
            boton_analizar("resultados_analizar")
        with b:
            if st.session_state.resultado:
                st.download_button("Descargar JSON  ⇩", json.dumps(st.session_state.resultado, indent=2, ensure_ascii=False),
                                   file_name="agrovision_resultado.json", mime="application/json", width="stretch")
    mostrar_estado()
    st.write("")
    panel_indicadores("Sin conectar")

    st.write("")
    left, right = st.columns([1.45, 1])
    with left:
        titulo_seccion("ANÁLISIS DE LAS CONDICIONES", "Tendencias")
        grafica_series("Pulsa «Analizar parcela» para ver las tendencias.")
    with right:
        titulo_seccion("RESUMEN", "Recomendación")
        bloque_recomendacion("Pulsa «Analizar parcela» para ver la recomendación.")

    resultado = st.session_state.resultado
    planes = resultado["plans"] if resultado else []
    titulo_seccion("OPCIONES DE CULTIVO", "Rotaciones sugeridas")
    if planes:
        for plan in planes:
            cultivos = " → ".join(plan["crops"])
            puntaje = f' · {plan["score"]:g}/100' if plan.get("score") is not None else ""
            st.markdown(
                f'<div class="plan-result"><h3>{seguro(plan["name"])}{seguro(puntaje)}</h3>'
                f'<p>{seguro(plan["description"])}</p>'
                + (f'<p><strong>{seguro(cultivos)}</strong></p>' if cultivos else "") + '</div>',
                unsafe_allow_html=True,
            )
    else:
        vacio("Sin estrategias todavía", "Pulsa «Analizar parcela» para calcular las rotaciones sugeridas.", "🌿")

    if resultado and resultado["meta"].get("source"):
        meta = resultado["meta"]
        st.caption("Origen: " + " · ".join(str(meta[k]) for k in ("source", "model_version", "generated_at") if meta.get(k)))


# ───────────────────────── PANTALLA 5: DATOS NASA ─────────────────────────
def pantalla_fuentes() -> None:
    encabezado(
        "FUENTES DE DATOS",
        "Fuentes de información.",
        "De dónde sale cada dato que ves en la página y en qué estado está.",
    )
    clima = (st.session_state.resultado or {}).get("climate", {})
    hay_clima = (clima.get("temperatureC") or {}).get("value") is not None
    hay_suelo = (clima.get("soilMoisturePct") or {}).get("value") is not None
    hay_ndvi = (clima.get("ndvi") or {}).get("value") is not None
    fuentes = [
        ("☀", "Datos meteorológicos", "Lluvia y temperatura mensuales de las estaciones CONAGUA (Amealco, Cadereyta de Montes y Pinal de Amoles)",
         "Conectado · CONAGUA" if hay_clima else "Listo · pulsa «Analizar parcela»"),
        ("◉", "Condiciones del suelo", "Humedad de la zona de raíces (GWETROOT) de NASA POWER, en vivo o desde la caché local",
         "Conectado · NASA POWER" if hay_suelo else "Sin datos · requiere internet o descargar_nasa.py"),
        ("✳", "Observación vegetal", "Índice de vegetación (NDVI): requiere cuenta Earthdata de NASA y no está conectado",
         "Conectado" if hay_ndvi else "Sin conectar"),
    ]
    for col, (icono, nombre, detalle, estado) in zip(st.columns(3), fuentes):
        with col:
            st.markdown(
                f'<div class="source-card"><div class="source-icon">{icono}</div>'
                f'<h3>{seguro(nombre)}</h3><p>{seguro(detalle)}</p><span>{seguro(estado)}</span></div>',
                unsafe_allow_html=True,
            )
    st.info("Los planes de rotación usan reglas agronómicas de referencia (no un modelo entrenado con cosechas) "
            "y el clima real de la estación más cercana. Las estimaciones de lluvia vienen del modelo Random Forest "
            "del equipo de datos. Valida los resultados con un agrónomo antes de decidir.")

    titulo_seccion("TRABAJO EN EQUIPO", "Contrato de integración")
    st.caption("Esto es exactamente lo que la interfaz envía y espera recibir. Úsalo para depurar la conexión.")
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**Entrada** (la parcela guardada)")
        if st.session_state.parcela:
            st.json(construir_entrada(st.session_state.parcela), expanded=False)
        else:
            st.caption("Guarda una parcela en «Mi parcela» para ver aquí los datos reales de entrada.")
    with c2:
        st.markdown("**Salida esperada** (formato completo)")
        st.json(EJEMPLO_SALIDA, expanded=False)
    if st.session_state.resultado:
        with st.expander("Último resultado recibido y validado"):
            st.json(st.session_state.resultado, expanded=False)

    titulo_seccion("ESTADO", "¿Qué falta integrar?")
    conectado = st.session_state.estado == "ok"
    st.markdown(
        '<div class="checklist-card"><p>✓ &nbsp; Diseño y navegación del frontend</p>'
        '<p>✓ &nbsp; Formulario con ubicación, ciclos previos y periodo de análisis</p>'
        '<p>✓ &nbsp; Validación de los datos y manejo de errores</p>'
        f'<p>{"✓" if conectado else "○"} &nbsp; Datos CONAGUA y modelo de lluvia (Random Forest)</p>'
        f'<p>{"✓" if hay_suelo else "○"} &nbsp; Humedad del suelo (NASA POWER)</p>'
        f'<p>{"✓" if hay_clima else "○"} &nbsp; Planes de rotación con reglas agronómicas</p>'
        '<p>○ &nbsp; NDVI y validación de las rotaciones con un agrónomo</p></div>',
        unsafe_allow_html=True,
    )


PANTALLAS = {
    "inicio": pantalla_inicio, "tutorial": pantalla_tutorial, "parcela": pantalla_parcela, "mapa": pantalla_mapa, "rotacion": pantalla_rotacion,
    "resultados": pantalla_resultados, "fuentes": pantalla_fuentes,
}
PANTALLAS[st.session_state.pagina]()

st.markdown(
    '<div class="footer"><span>© 2026 AgroVision · Prototipo educativo</span>'
    '<span>Desarrollado para NASA Space Apps Challenge · No afiliado a NASA</span></div>',
    unsafe_allow_html=True,
)
