"""PUNTO DE CONEXIÓN con el algoritmo del equipo de ML.

El equipo de ML solo debe editar ESTE archivo. No hay lógica agrícola ni
llamadas a NASA en el resto de la aplicación.

Reglas:
  * Devolver None            -> «el algoritmo aún no está conectado» (no es un error).
  * Devolver un diccionario  -> ver contrato.EJEMPLO_SALIDA / INTEGRACION_FUTURA.md.
  * Lanzar una excepción     -> la pantalla muestra el error (no se cae ni inventa datos).

Dos formas de conectarlo (elige una):
  A) Python local: implementa _algoritmo_local() (importa tu modelo y llámalo).
  B) API externa : define la variable de entorno AGROVISION_API_URL (y opcional
     AGROVISION_API_KEY) y se usará _llamar_api() automáticamente.
     NUNCA escribas claves en el código ni las subas a GitHub.

Probar sin abrir Streamlit:   python verificar_integracion.py
"""

from __future__ import annotations

import os


def analizar_parcela(datos: dict) -> dict | None:
    """Recibe la parcela (ver contrato.construir_entrada) y devuelve el análisis."""
    url = os.getenv("AGROVISION_API_URL")
    if url:
        return _llamar_api(url, datos)
    return _algoritmo_local(datos)


def _algoritmo_local(datos: dict) -> dict | None:
    """Conecta los datos CONAGUA y el modelo Random Forest del equipo de ML (carpeta ml/)."""
    from datetime import date

    import pandas as pd

    from ml import clima_conagua as cc

    lat, lon = datos.get("latitud"), datos.get("longitud")
    if lat is None or lon is None:
        raise ValueError("Falta latitud/longitud de la parcela para elegir la estación meteorológica.")

    clave, est, km = cc.estacion_cercana(float(lat), float(lon))
    tabla = est["tabla"].dropna(subset=["lluvia_total", "temp_media"], how="all").copy()
    if tabla.empty:
        raise ValueError(f"La estación {est['nombre']} no trae mediciones.")
    tabla["fecha"] = pd.to_datetime(dict(year=tabla["anio"], month=tabla["num_mes"], day=1))

    # Meses reales del periodo pedido; si no hay, los últimos 12 con dato.
    ini, fin = pd.Timestamp(datos.get("periodo_inicio") or "1900-01-01"), pd.Timestamp(datos.get("periodo_fin") or "2100-01-01")
    en_periodo = tabla[(tabla["fecha"] >= ini) & (tabla["fecha"] <= fin)]
    usados = en_periodo if len(en_periodo) else tabla.tail(12)
    aviso_periodo = "" if len(en_periodo) else " (el periodo pedido no tiene datos; se muestran los últimos 12 meses con medición)"

    # Humedad del suelo de NASA POWER (en vivo o desde la caché); None si no hay internet ni caché.
    from ml import nasa_power, rotacion

    humedad = None
    try:
        humedad = nasa_power.humedad_suelo(float(lat), float(lon), datos.get("periodo_inicio") or "2025-01-01",
                                           datos.get("periodo_fin") or date.today().isoformat())
    except Exception:  # noqa: BLE001 - la humedad es opcional: sin ella el resto sigue funcionando
        humedad = None

    fuente = f"CONAGUA estación {clave} {est['nombre']} (a {km:.0f} km de la parcela)"
    ultimo = usados.iloc[-1]
    etiqueta = {"source": f"CONAGUA · est. {clave} {est['nombre']} ({km:.0f} km)", "date": ultimo["fecha"].strftime("%Y-%m")}

    def ok(v):
        return None if pd.isna(v) else round(float(v), 2)

    por_mes = {r["fecha"].strftime("%Y-%m"): {"date": r["fecha"].strftime("%Y-%m"), "temperatureC": ok(r["temp_media"]),
                                               "rainfallMm": ok(r["lluvia_total"])} for _, r in usados.iterrows()}
    if humedad:
        for f in humedad["serie"]:
            por_mes.setdefault(f["date"], {"date": f["date"]})["soilMoisturePct"] = f["soilMoisturePct"]
    serie = [por_mes[k] for k in sorted(por_mes)]
    clima = {
        "temperatureC": {"value": ok(ultimo["temp_media"]), **etiqueta},
        "rainfallMm": {"value": ok(ultimo["lluvia_total"]), **etiqueta},
    }
    if humedad:
        ult_h = humedad["serie"][-1]
        clima["soilMoisturePct"] = {"value": ult_h["soilMoisturePct"], "source": humedad["fuente_corta"], "date": ult_h["date"]}
    planes, nota_planes = rotacion.proponer(tabla, datos, humedad["serie"] if humedad else None, est["nombre"])

    # Pronóstico con el modelo: lluvia estimada de los próximos 3 meses frente a la mediana histórica de ese mes.
    clim = cc.climatologia(tabla)
    hoy = date.today()
    previsiones = []
    for k in range(1, 4):
        mes0 = hoy.month - 1 + k
        anio, mes = hoy.year + mes0 // 12, mes0 % 12 + 1
        mm = cc.predecir_lluvia(tabla, anio, mes)
        previsiones.append((cc.MESES[mes - 1].title(), mm, float(clim.loc[mes, "lluvia_mediana"])))
    texto_prev = "; ".join(f"{m}: ~{mm:.0f} mm (normal {med:.0f} mm)" for m, mm, med in previsiones)
    total_prev, total_med = sum(p[1] for p in previsiones), sum(p[2] for p in previsiones)
    tendencia = "por encima" if total_prev > total_med * 1.1 else "por debajo" if total_prev < total_med * 0.9 else "cerca"
    recomendacion = (
        f"Estimación de lluvia (modelo Random Forest, referencia estación {est['nombre']}) para los próximos 3 meses: {texto_prev}. "
        f"En conjunto queda {tendencia} de lo normal histórico. Es una estimación a partir de la estación más cercana "
        f"({km:.0f} km): úsala como orientación, no como pronóstico oficial{aviso_periodo}."
        + "\n\n" + nota_planes
        + ("" if humedad else "\n\nHumedad del suelo: no se pudo consultar NASA POWER (sin internet ni caché); corre descargar_nasa.py con internet.")
        + "\n\nNDVI: aún no conectado (requiere cuenta Earthdata de NASA)."
    )
    return {
        "climate": clima,
        "series": serie,
        "recommendation": recomendacion,
        "plans": planes,
        "meta": {"source": fuente + (" · " + humedad["fuente"] if humedad else ""), "generated_at": hoy.isoformat(), "model_version": "RandomForest regresion (lluvia_total)"},
    }


def _llamar_api(url: str, datos: dict) -> dict:
    """Opción B: el algoritmo vive en otro servidor."""
    import requests  # import local: solo se necesita si se usa la API

    cabeceras = {}
    if os.getenv("AGROVISION_API_KEY"):
        cabeceras["Authorization"] = f"Bearer {os.environ['AGROVISION_API_KEY']}"
    respuesta = requests.post(url, json=datos, headers=cabeceras, timeout=60)
    respuesta.raise_for_status()
    return respuesta.json()
