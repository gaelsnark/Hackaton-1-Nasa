"""Descarga UNA VEZ (con internet) la humedad del suelo de NASA POWER para las 3 estaciones.

    py descargar_nasa.py

Guarda ml/datos/cache_nasa/*.json. Así la página sigue mostrando humedad del suelo real
aunque el día de la presentación no haya internet.
"""
from datetime import date

from ml import clima_conagua as cc
from ml import nasa_power as np_

for clave, est in cc.estaciones().items():
    try:
        filas = np_.descargar(est["lat"], est["lon"], 2015, date.today().year)
        print(f"OK  {clave} {est['nombre']}: {len(filas)} meses (de {filas[0]['date']} a {filas[-1]['date']})")
    except Exception as exc:  # noqa: BLE001
        print(f"ERROR {clave} {est['nombre']}: {type(exc).__name__}: {exc}")
