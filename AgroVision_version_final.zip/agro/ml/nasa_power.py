"""Humedad del suelo desde NASA POWER (https://power.larc.nasa.gov), sin clave de API.

Variables mensuales que se piden (comunidad AG = agroclimatología, modelo MERRA-2):
  GWETROOT  humedad de la zona de raíces  (fracción 0-1 de saturación)  -> soilMoisturePct (x100)
  GWETTOP   humedad de la superficie      (fracción 0-1 de saturación)

Orden de uso (nunca se inventa un valor):
  1. Consulta en vivo a NASA POWER (timeout corto).
  2. Si no hay internet, usa el archivo de caché de ml/datos/cache_nasa/ (lo crea descargar_nasa.py
     o se guarda solo tras cada consulta exitosa). La caché de otro punto se usa solo si está en la
     misma celda de ~0.5° y se avisa en la fuente.
  3. Si no hay nada, devuelve None y la app muestra «—».
"""

from __future__ import annotations

import json
import math
import re
from datetime import date
from pathlib import Path

URL = "https://power.larc.nasa.gov/api/temporal/monthly/point"
CACHE = Path(__file__).parent / "datos" / "cache_nasa"
PARAMETROS = "GWETROOT,GWETTOP"
FALTANTE = -990  # POWER marca los datos que faltan con -999
DIAS_CACHE = 7   # la caché del mismo punto se considera vigente por una semana


def _archivo(lat: float, lon: float) -> Path:
    return CACHE / f"power_{lat:.2f}_{lon:.2f}.json"


def _parsear(respuesta: dict) -> list[dict]:
    """JSON de POWER -> [{'date': 'YYYY-MM', 'soilMoisturePct': 41.3, 'topPct': 38.0}, ...] ordenado."""
    param = respuesta["properties"]["parameter"]
    raiz, sup = param.get("GWETROOT", {}), param.get("GWETTOP", {})
    filas = []
    for clave in sorted(raiz):
        anio, mes = int(clave[:4]), int(clave[4:])
        if not 1 <= mes <= 12:  # el mes 13 es el promedio anual
            continue
        v = raiz[clave]
        if v is None or v <= FALTANTE:
            continue
        t = sup.get(clave)
        filas.append({
            "date": f"{anio}-{mes:02d}", "soilMoisturePct": round(float(v) * 100, 1),
            "topPct": round(float(t) * 100, 1) if t is not None and t > FALTANTE else None,
        })
    return filas


def descargar(lat: float, lon: float, anio_ini: int, anio_fin: int, timeout: tuple = (5, 20)) -> list[dict]:
    """Consulta POWER (necesita internet) y guarda la caché. Lanza excepción si falla."""
    import requests

    r = requests.get(URL, params={
        "parameters": PARAMETROS, "community": "AG", "latitude": round(lat, 4), "longitude": round(lon, 4),
        "start": anio_ini, "end": anio_fin, "format": "JSON",
    }, timeout=timeout)
    r.raise_for_status()
    filas = _parsear(r.json())
    if filas:
        try:
            CACHE.mkdir(parents=True, exist_ok=True)
            _archivo(lat, lon).write_text(json.dumps(
                {"lat": lat, "lon": lon, "descargado": date.today().isoformat(), "filas": filas},
                ensure_ascii=False), encoding="utf-8")
        except OSError:
            pass  # la caché es opcional
    return filas


def _leer_cache(lat: float, lon: float) -> tuple[list[dict], str, bool, str] | None:
    """Caché del punto exacto o, si no existe, de otro punto dentro de ~0.5° (misma celda de la malla)."""
    if not CACHE.exists():
        return None
    mejor, dist = None, 1e9
    for ruta in CACHE.glob("power_*.json"):
        try:
            d = json.loads(ruta.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        dd = math.hypot(d["lat"] - lat, (d["lon"] - lon) * math.cos(math.radians(lat)))
        if dd < dist:
            mejor, dist = d, dd
    if mejor is None or dist > 0.5:
        return None
    exacto = dist < 0.01
    nota = "caché local" if exacto else f"caché local de un punto cercano ({mejor['lat']:.2f}, {mejor['lon']:.2f})"
    return mejor["filas"], f"{nota}, descargada {mejor['descargado']}", exacto, mejor["descargado"]


def humedad_suelo(lat: float, lon: float, inicio: str, fin: str) -> dict | None:
    """{'serie': [...], 'fuente': str} con los meses del periodo, o None si no hay datos.

    inicio / fin: fechas ISO 'YYYY-MM-DD'.
    """
    ini_mes, fin_mes = inicio[:7], fin[:7]
    origen = "NASA POWER (en vivo)"
    cache = _leer_cache(lat, lon)
    reciente = cache is not None and cache[2] and (date.today() - date.fromisoformat(cache[3])).days < DIAS_CACHE
    if reciente:  # caché del mismo punto de hace pocos días: no hace falta volver a consultar
        filas, nota = cache[0], cache[1]
        origen = f"NASA POWER ({nota})"
    else:
        try:
            filas = descargar(lat, lon, int(inicio[:4]), int(fin[:4]))
        except Exception:  # noqa: BLE001 - sin internet, límite de uso, etc.: se usa la caché que haya
            if cache is None:
                return None
            filas, nota = cache[0], cache[1]
            origen = f"NASA POWER ({nota})"
    serie = [f for f in filas if ini_mes <= f["date"] <= fin_mes]
    if not serie:  # el periodo pedido no tiene datos: se toman los últimos 12 meses disponibles
        serie = filas[-12:]
    if not serie:
        return None
    corta = re.sub(r"caché local de un punto cercano \([^)]*\), descargada", "caché de punto cercano", origen)
    corta = corta.replace("caché local, descargada", "caché")
    return {"serie": serie, "fuente": f"{origen} · GWETROOT (humedad de la zona de raíces, MERRA-2)",
            "fuente_corta": f"{corta} · humedad de raíces"}
