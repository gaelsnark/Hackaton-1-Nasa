"""Planes de rotación de cultivos a partir del clima REAL de la estación y reglas agronómicas.

Cómo funciona (explicable en una presentación):
  1. Para cada cultivo se calcula qué tan bien encaja en el ciclo donde se siembra
     (primavera-verano = mayo-octubre, otoño-invierno = noviembre-abril, perenne = todo el año):
       · temperatura  ¿la temperatura media del ciclo cae en el rango del cultivo?   (datos CONAGUA)
       · agua         ¿la lluvia del ciclo cubre lo que el cultivo necesita?          (datos CONAGUA,
                      ajustada un poco con la humedad del suelo de NASA POWER si está disponible)
       · helada       ¿hay riesgo de helada en los meses del ciclo?                    (datos CONAGUA)
       · rotación     no repetir cultivo ni familia botánica; las leguminosas fijan nitrógeno
       · suelo        pequeños ajustes por tipo de suelo
       · consumo      cuánta agua demanda (importa si el objetivo es ahorrar agua)
  2. Según el objetivo del productor se cambian los pesos de esos criterios.
  3. Se arman secuencias de 3 cultivos anuales sucesivos, eligiendo cada vez el mejor dado lo ya sembrado.
     (Alfalfa y agave son perennes: se puntúan pero no entran como paso de una rotación de ciclos cortos.)

IMPORTANTE: los valores de la tabla CULTIVOS son rangos agronómicos de referencia APROXIMADOS (tipo FAO).
No salen de datos de cosechas ni de un modelo entrenado: son reglas. Conviene que un agrónomo los
revise y ajuste (están todos en la tabla, un cultivo por línea).
"""

from __future__ import annotations

import math

import numpy as np
import pandas as pd

MESES_CICLO = {
    "primavera-verano": [5, 6, 7, 8, 9, 10],
    "otoño-invierno": [11, 12, 1, 2, 3, 4],
    "perenne": list(range(1, 13)),
}

# familia, ciclo, agua (mm que necesita en el ciclo), temperatura (mín viable, óptima baja, óptima alta, máx viable),
# sensible a helada, tolerancia a sequía (0-1), nitrógeno, requiere riego para ir bien, cultivo de cobertura
CULTIVOS: dict[str, dict] = {
    "Maíz":     dict(familia="Gramíneas",    ciclo="primavera-verano", agua=650, temp=(10, 16, 27, 35), helada=True,  sequia=0.35, n="alta",  riego=False, cobertura=False),
    "Frijol":   dict(familia="Leguminosas",  ciclo="primavera-verano", agua=400, temp=(10, 15, 25, 32), helada=True,  sequia=0.50, n="fija",  riego=False, cobertura=False),
    "Sorgo":    dict(familia="Gramíneas",    ciclo="primavera-verano", agua=500, temp=(15, 22, 32, 38), helada=True,  sequia=0.85, n="media", riego=False, cobertura=False),
    "Trigo":    dict(familia="Gramíneas",    ciclo="otoño-invierno",   agua=550, temp=(4, 10, 24, 32),  helada=False, sequia=0.40, n="media", riego=False, cobertura=False),
    "Cebada":   dict(familia="Gramíneas",    ciclo="otoño-invierno",   agua=375, temp=(4, 8, 22, 30),   helada=False, sequia=0.60, n="media", riego=False, cobertura=False),
    "Avena":    dict(familia="Gramíneas",    ciclo="otoño-invierno",   agua=425, temp=(4, 8, 22, 30),   helada=False, sequia=0.50, n="baja",  riego=False, cobertura=True),
    "Alfalfa":  dict(familia="Leguminosas",  ciclo="perenne",          agua=1000, temp=(5, 15, 25, 35), helada=False, sequia=0.50, n="fija",  riego=True,  cobertura=True),
    "Chile":    dict(familia="Solanáceas",   ciclo="primavera-verano", agua=700, temp=(13, 18, 28, 35), helada=True,  sequia=0.25, n="alta",  riego=True,  cobertura=False),
    "Jitomate": dict(familia="Solanáceas",   ciclo="primavera-verano", agua=600, temp=(12, 18, 27, 34), helada=True,  sequia=0.25, n="alta",  riego=True,  cobertura=False),
    "Agave":    dict(familia="Agaváceas",    ciclo="perenne",          agua=450, temp=(10, 15, 30, 40), helada=False, sequia=1.00, n="baja",  riego=False, cobertura=False),
}

# Aprovechamiento del agua según el riego (si hay riego, el agua no limita pero sí cuesta).
EFICIENCIA_RIEGO = {"Riego por goteo": 0.9, "Riego por aspersión": 0.75, "Riego por gravedad": 0.6}

PERFILES = {  # pesos de cada criterio según el objetivo
    "equilibrado":   dict(temp=.20, agua=.30, helada=.10, rot=.25, suelo=.05, consumo=.10, salud=.00),
    "agua":          dict(temp=.15, agua=.30, helada=.10, rot=.15, suelo=.05, consumo=.25, salud=.00),
    "suelo":         dict(temp=.15, agua=.20, helada=.10, rot=.20, suelo=.10, consumo=.05, salud=.20),
    "diversificar":  dict(temp=.15, agua=.25, helada=.10, rot=.40, suelo=.05, consumo=.05, salud=.00),
}
NOMBRE_PERFIL = {"equilibrado": "Equilibrado", "agua": "Ahorro de agua",
                 "suelo": "Cuidado del suelo", "diversificar": "Diversificación"}
PERFIL_DE_PRIORIDAD = {"Ahorrar agua": "agua", "Cuidar el suelo": "suelo",
                       "Diversificar cultivos": "diversificar", "Equilibrar objetivos": "equilibrado"}
PUNTAJE_MINIMO = 0.40   # un cultivo por debajo de esto no se propone
MIN_AGUA = 0.50         # el agua (lluvia o riego) debe cubrir al menos la mitad de lo que necesita
MIN_TEMP = 0.30         # la temperatura del ciclo no puede quedar casi fuera del rango viable
N_CULTIVOS_PLAN = 3


# ───────────────────────── clima de la estación ─────────────────────────
def perfil_clima(tabla: pd.DataFrame) -> dict:
    """Promedios mensuales históricos: lluvia, temperatura media y probabilidad de helada por mes (1-12)."""
    t = tabla[tabla["anio"] >= 1990] if (tabla["anio"] >= 1990).sum() >= 120 else tabla
    mes = t.groupby("num_mes")
    lluvia = mes["lluvia_total"].mean()
    temp = mes["temp_media"].mean()
    helada = mes["temp_min_ext"].apply(lambda s: float((s.dropna() <= 0).mean()) if s.notna().any() else np.nan)
    return {"lluvia": lluvia, "temp": temp, "helada": helada, "anios": int(t["anio"].nunique())}


def _ciclo(clima: dict, ciclo: str) -> dict:
    meses = MESES_CICLO[ciclo]
    lluvia = float(sum(clima["lluvia"].get(m, 0) or 0 for m in meses))
    temps = [clima["temp"].get(m) for m in meses if pd.notna(clima["temp"].get(m))]
    probs = [clima["helada"].get(m) for m in meses if pd.notna(clima["helada"].get(m))]
    riesgo = 1 - math.prod(1 - p for p in probs) if probs else 0.0
    return {"lluvia": lluvia, "temp": float(np.mean(temps)) if temps else float("nan"), "helada": float(riesgo),
            "meses": meses}


def _humedad_ciclo(serie_nasa: list[dict] | None, meses: list[int]) -> float | None:
    """Humedad media de la zona de raíces (0-1) en los meses del ciclo, con datos NASA POWER."""
    if not serie_nasa:
        return None
    vals = [f["soilMoisturePct"] / 100 for f in serie_nasa if int(f["date"][5:7]) in meses and f.get("soilMoisturePct") is not None]
    return float(np.mean(vals)) if vals else None


# ───────────────────────── puntajes (todos 0-1) ─────────────────────────
def _trapecio(x: float, rango: tuple[float, float, float, float]) -> float:
    mn, lo, hi, mx = rango
    if math.isnan(x) or x <= mn or x >= mx:
        return 0.0
    if x < lo:
        return (x - mn) / (lo - mn)
    if x > hi:
        return (mx - x) / (mx - hi)
    return 1.0


def _puntajes(nombre: str, cultivo: str, historial: list[str], ciclos: dict, parcela: dict,
              serie_nasa: list[dict] | None) -> tuple[dict, dict]:
    c = CULTIVOS[nombre]
    ci = ciclos[c["ciclo"]]
    riego = parcela.get("tipo_riego") or "Temporal (solo lluvia)"
    con_riego = riego in EFICIENCIA_RIEGO
    suelo = parcela.get("tipo_suelo")

    # agua
    necesita = c["agua"] * (1 - 0.35 * c["sequia"])
    humedad = _humedad_ciclo(serie_nasa, ci["meses"])
    factor_nasa = 1.0 if humedad is None else min(1.10, max(0.90, 1 + 0.25 * (humedad - 0.45)))
    lluvia_util = ci["lluvia"] * 0.85 * factor_nasa
    if con_riego:
        agua_s = 1.0
    else:
        agua_s = min(1.0, lluvia_util / necesita)
        if c["riego"]:
            agua_s *= 0.4   # cultivos que casi siempre se riegan: la lluvia sola no basta
    consumo_s = 1 - min(1.0, necesita / 900)

    # temperatura y helada
    temp_s = _trapecio(ci["temp"], c["temp"])
    helada_s = 1 - min(1.0, ci["helada"] * 1.5) if c["helada"] else 1 - min(0.3, ci["helada"] * 0.3)

    # rotación
    actual = historial[-1] if historial else None
    fam_prev = {CULTIVOS[h]["familia"] for h in historial if h in CULTIVOS}
    if nombre == actual:
        rot_s = 0.15
    elif actual in CULTIVOS and c["familia"] == CULTIVOS[actual]["familia"]:
        rot_s = 0.45
    elif c["familia"] in fam_prev:
        rot_s = 0.80
    else:
        rot_s = 1.0
    # sembrar el mismo cultivo dos veces en el historial reciente también resta
    if historial[-2:].count(nombre) and nombre != actual:
        rot_s = min(rot_s, 0.6)

    # suelo
    suelo_s = 1.0
    if suelo == "Arenoso" and c["sequia"] < 0.7:
        suelo_s = 0.9
    elif suelo == "Arcilloso" and nombre == "Agave":
        suelo_s = 0.8
    elif suelo == "Calcáreo" and nombre == "Frijol":
        suelo_s = 0.85
    elif suelo == "Calcáreo" and nombre != "Sorgo":
        suelo_s = 0.95

    # salud del suelo (solo pesa con el objetivo «cuidar el suelo»)
    salud_s = {"fija": 1.0, "baja": 0.7, "media": 0.5, "alta": 0.3}[c["n"]]
    if c["cobertura"]:
        salud_s = min(1.0, salud_s + 0.2)

    punt = dict(temp=temp_s, agua=agua_s, helada=helada_s, rot=rot_s, suelo=suelo_s, consumo=consumo_s, salud=salud_s)
    info = dict(lluvia=ci["lluvia"], necesita=c["agua"], temp=ci["temp"], helada=ci["helada"], humedad=humedad,
                con_riego=con_riego, ciclo=c["ciclo"])
    return punt, info


def _total(punt: dict, perfil: str) -> float:
    pesos = PERFILES[perfil]
    return sum(punt[k] * w for k, w in pesos.items()) / sum(pesos.values())


def _razon(nombre: str, punt: dict, info: dict, anterior: str | None) -> str:
    c = CULTIVOS[nombre]
    partes = []
    if info["con_riego"]:
        partes.append(f"con riego el agua no limita (necesita ~{info['necesita']:.0f} mm)")
    else:
        partes.append(f"lluvia esperada del ciclo ~{info['lluvia']:.0f} mm frente a ~{info['necesita']:.0f} mm que necesita")
    if punt["temp"] < 0.6:
        partes.append(f"la temperatura media del ciclo ({info['temp']:.1f} °C) queda fuera de su rango ideal")
    if c["helada"] and info["helada"] > 0.15:
        partes.append(f"hay riesgo de helada ({info['helada'] * 100:.0f} % de los años)")
    if anterior and anterior in CULTIVOS:
        if c["n"] == "fija" and CULTIVOS[anterior]["n"] in ("alta", "media"):
            partes.append(f"fija nitrógeno después de {anterior}")
        elif CULTIVOS[anterior]["familia"] != c["familia"]:
            partes.append(f"cambia de familia respecto a {anterior}")
        else:
            partes.append(f"misma familia que {anterior}: conviene vigilar plagas y enfermedades")
    if info["humedad"] is not None:
        partes.append(f"humedad del suelo NASA ~{info['humedad'] * 100:.0f} %")
    return "; ".join(partes)


# ───────────────────────── planes ─────────────────────────
def _secuencia(perfil: str, historial: list[str], ciclos: dict, parcela: dict, serie_nasa: list[dict] | None,
               primero: str | None = None):
    hist = list(historial)
    elegidos = []
    for paso in range(N_CULTIVOS_PLAN):
        candidatos = []
        for nombre in CULTIVOS:
            if CULTIVOS[nombre]["ciclo"] == "perenne":
                continue  # alfalfa y agave duran varios años: no entran en una rotación de ciclos cortos
            if paso == 0 and primero and nombre != primero:
                continue  # alternativa que obliga a empezar con otro cultivo
            if hist and nombre == hist[-1]:
                continue  # nunca el mismo cultivo dos ciclos seguidos
            punt, info = _puntajes(nombre, nombre, hist, ciclos, parcela, serie_nasa)
            if punt["agua"] < MIN_AGUA or punt["temp"] < MIN_TEMP:
                continue  # no es viable con el agua o la temperatura de la estación
            candidatos.append((_total(punt, perfil), nombre, punt, info))
        candidatos.sort(key=lambda x: -x[0])
        if not candidatos or candidatos[0][0] < PUNTAJE_MINIMO:
            break
        mejor = candidatos[0]
        anterior = hist[-1] if hist else None
        elegidos.append({"cultivo": mejor[1], "puntaje": mejor[0], "razon": _razon(mejor[1], mejor[2], mejor[3], anterior),
                         "ciclo": mejor[3]["ciclo"]})
        hist.append(mejor[1])
    return elegidos


def proponer(tabla: pd.DataFrame, parcela: dict, serie_nasa: list[dict] | None = None, estacion: str = "") -> tuple[list[dict], str]:
    """Devuelve (planes en el formato de contrato.py, nota explicativa)."""
    clima = perfil_clima(tabla)
    ciclos = {nombre: _ciclo(clima, nombre) for nombre in MESES_CICLO}
    actual = parcela.get("cultivo")
    historial = [c for c in (parcela.get("cultivos_previos") or []) if c in CULTIVOS and c != actual]
    if actual in CULTIVOS:
        historial.append(actual)

    prioridad = PERFIL_DE_PRIORIDAD.get(parcela.get("prioridad"), "equilibrado")
    orden = [prioridad] + [p for p in ("equilibrado", "agua", "suelo", "diversificar") if p != prioridad]
    planes, vistos = [], set()
    for perfil in orden:
        seq = _secuencia(perfil, historial, ciclos, parcela, serie_nasa)
        clave = tuple(s["cultivo"] for s in seq)
        if not seq or clave in vistos:
            continue
        vistos.add(clave)
        letra = "ABC"[len(planes)]
        etiqueta = NOMBRE_PERFIL[perfil] + (" · tu objetivo" if perfil == prioridad else "")
        detalle = " ".join(f"{i}) {s['cultivo']} ({s['ciclo']}): {s['razon']}." for i, s in enumerate(seq, 1))
        planes.append({
            "name": f"Plan {letra} · {etiqueta}",
            "description": detalle,
            "crops": [s["cultivo"] for s in seq],
            "score": round(float(np.mean([s["puntaje"] for s in seq])) * 100),
        })
        if len(planes) == 3:
            break

    # Si hay pocos cultivos viables, los perfiles dan el mismo plan: se ofrecen alternativas que empiezan distinto.
    if len(planes) < 3:
        iniciales = [c for c in CULTIVOS if CULTIVOS[c]["ciclo"] != "perenne" and c != (historial[-1] if historial else None)]
        usados = {p["crops"][0] for p in planes}
        for primero in sorted(iniciales, key=lambda c: -_total(_puntajes(c, c, historial, ciclos, parcela, serie_nasa)[0], prioridad)):
            if len(planes) == 3:
                break
            if primero in usados:
                continue
            seq = _secuencia(prioridad, historial, ciclos, parcela, serie_nasa, primero=primero)
            clave = tuple(s["cultivo"] for s in seq)
            if not seq or clave in vistos:
                continue
            vistos.add(clave)
            usados.add(primero)
            detalle = " ".join(f"{i}) {s['cultivo']} ({s['ciclo']}): {s['razon']}." for i, s in enumerate(seq, 1))
            planes.append({
                "name": f"Plan {'ABC'[len(planes)]} · Alternativa que empieza con {primero}",
                "description": detalle, "crops": [s["cultivo"] for s in seq],
                "score": round(float(np.mean([s["puntaje"] for s in seq])) * 100),
            })

    sin_riego = (parcela.get("tipo_riego") or "Temporal (solo lluvia)") not in EFICIENCIA_RIEGO
    ci_pv, ci_oi = ciclos["primavera-verano"], ciclos["otoño-invierno"]
    nota = (f"Plan calculado con {clima['anios']} años de datos de la estación {estacion}: lluvia media de ~{ci_pv['lluvia']:.0f} mm en "
            f"primavera-verano y ~{ci_oi['lluvia']:.0f} mm en otoño-invierno. ")
    if sin_riego and 0 < len(planes) < 3:
        nota += "Se muestran pocos planes porque con solo lluvia son pocos los cultivos que encajan con esta zona. "
    if sin_riego:
        nota += "Al ser de temporal (solo lluvia), los cultivos de otoño-invierno casi no aparecen porque en esa época llueve muy poco. "
    nota += "Los rangos de cada cultivo son valores agronómicos de referencia aproximados; valídalos con un agrónomo antes de decidir."
    if CULTIVOS.get(actual, {}).get("ciclo") == "perenne":
        nota += f" {actual} es perenne: los planes muestran qué sembrar cuando termine su ciclo productivo."
    elif any(CULTIVOS.get(c, {}).get("ciclo") == "perenne" for c in (parcela.get("cultivos_previos") or [])):
        nota += " Alfalfa y agave son perennes y no se incluyen como pasos de la rotación."
    if not planes:
        nota = ("Ningún cultivo de la lista alcanza un encaje mínimo con el clima de la estación " + estacion +
                ". " + nota)
    return planes, nota
