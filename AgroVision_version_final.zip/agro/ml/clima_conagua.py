"""Datos CONAGUA + modelo Random Forest del equipo de ML, listos para la app.

Qué hace:
  1. Lee los .txt mensuales de las estaciones (ml/datos/mes*.txt) con la misma lógica de limpieza_de_datos.py.
  2. Elige la estación más cercana a la parcela (por latitud/longitud).
  3. Arma la serie mensual real (lluvia y temperatura) del periodo pedido.
  4. Usa el modelo ajustado (modelo_ajustado_regresion.pkl) para ESTIMAR la lluvia de los meses sin dato.

Lo que NO hay en estos datos (y por eso la app lo deja vacío en vez de inventarlo):
  humedad del suelo, NDVI y rendimiento de cultivos.
"""

from __future__ import annotations

import math
import re
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd

CARPETA = Path(__file__).parent / "datos"
MODELO = CARPETA / "modelo_ajustado_regresion.pkl"
MESES = ["ENE", "FEB", "MAR", "ABR", "MAY", "JUN", "JUL", "AGO", "SEP", "OCT", "NOV", "DIC"]
TABLAS = {
    "LLUVIA MÁXIMA 24 H.": "lluvia_max_24h", "LLUVIA TOTAL MENSUAL": "lluvia_total",
    "EVAPORACIÓN MENSUAL": "evaporacion", "TEMPERATURA MÁXIMA PROMEDIO": "temp_max_prom",
    "TEMPERATURA MÁXIMA EXTREMA": "temp_max_ext", "TEMPERATURA MÍNIMA PROMEDIO": "temp_min_prom",
    "TEMPERATURA MÍNIMA EXTREMA": "temp_min_ext", "TEMPERATURA MEDIA MENSUAL": "temp_media",
}
FEATURES_TEMP = ["temp_max_prom", "temp_max_ext", "temp_min_prom", "temp_min_ext", "temp_media"]


def _leer_texto(ruta: Path) -> str:
    crudo = ruta.read_bytes()
    try:
        return crudo.decode("utf-8")
    except UnicodeDecodeError:
        return crudo.decode("latin-1")


def _numero_de(texto: str, etiqueta: str) -> float | None:
    m = re.search(rf"{etiqueta}\s*:\s*(-?[\d.]+)", texto)
    return float(m.group(1)) if m else None


def _titulo(texto: str) -> str:
    """'CADEREYTA DE MONTES' -> 'Cadereyta de Montes'."""
    return " ".join(p if p in ("de", "del", "la", "los") else p.capitalize() for p in texto.strip().lower().split())


@lru_cache(maxsize=1)
def estaciones() -> dict[str, dict]:
    """clave de estación -> {nombre, municipio, lat, lon, altitud, tabla (DataFrame mensual)}."""
    resultado: dict[str, dict] = {}
    for ruta in sorted(CARPETA.glob("mes*.txt")):
        texto = _leer_texto(ruta)
        nombre = re.search(r"NOMBRE\s*:\s*(.+)", texto)
        municipio = re.search(r"MUNICIPIO\s*:\s*(.+)", texto)
        clave = re.search(r"ESTACI[OÓ]N\s*:\s*(\d+)", texto)
        datos: dict[tuple[int, int], dict] = {}
        variable = ""
        for linea in texto.splitlines():
            partes = linea.split("\t")
            primera = partes[0].strip()
            if linea.strip() in TABLAS:
                variable = TABLAS[linea.strip()]
            elif variable and primera.isdigit() and len(primera) == 4:
                partes += [""] * (13 - len(partes))
                for i in range(12):
                    try:
                        valor = float(partes[i + 1].strip())
                    except ValueError:
                        valor = np.nan
                    datos.setdefault((int(primera), i), {})[variable] = valor
        filas = [{"anio": a, "mes": MESES[m], "num_mes": m + 1, **v} for (a, m), v in sorted(datos.items())]
        tabla = pd.DataFrame(filas)
        for col in TABLAS.values():
            if col not in tabla:
                tabla[col] = np.nan
        resultado[clave.group(1) if clave else ruta.stem] = {
            "nombre": (_titulo(nombre.group(1)) if nombre else ruta.stem),
            "municipio": (_titulo(municipio.group(1)) if municipio else ""),
            "lat": _numero_de(texto, "LATITUD"), "lon": _numero_de(texto, "LONGITUD"),
            "altitud": _numero_de(texto, "ALTITUD"), "tabla": tabla,
        }
    return resultado


def _km(lat1, lon1, lat2, lon2) -> float:
    p = math.pi / 180
    a = (math.sin((lat2 - lat1) * p / 2) ** 2
         + math.cos(lat1 * p) * math.cos(lat2 * p) * math.sin((lon2 - lon1) * p / 2) ** 2)
    return 12742 * math.asin(math.sqrt(a))


def estacion_cercana(lat: float, lon: float) -> tuple[str, dict, float]:
    """(clave, estación, distancia_km) de la estación CONAGUA más cercana."""
    todas = estaciones()
    if not todas:
        raise FileNotFoundError(f"No hay archivos mes*.txt en {CARPETA}")
    clave = min(todas, key=lambda k: _km(lat, lon, todas[k]["lat"], todas[k]["lon"]))
    est = todas[clave]
    return clave, est, _km(lat, lon, est["lat"], est["lon"])


@lru_cache(maxsize=1)
def _modelo():
    import joblib
    return joblib.load(MODELO)


def climatologia(tabla: pd.DataFrame) -> pd.DataFrame:
    """Promedio y mediana histórica por mes (sirve para rellenar temperaturas y comparar la lluvia)."""
    cols = ["lluvia_total"] + FEATURES_TEMP
    g = tabla.groupby("num_mes")[cols]
    prom, med = g.mean(), g.median()
    prom["lluvia_mediana"] = med["lluvia_total"]
    return prom


def predecir_lluvia(tabla: pd.DataFrame, anio: int, num_mes: int) -> float:
    """Lluvia estimada (mm) de un mes con el modelo; las temperaturas se toman del promedio histórico del mes."""
    clim = climatologia(tabla).loc[num_mes]
    fila = {"anio": anio, "mes": MESES[num_mes - 1], **{c: clim[c] for c in FEATURES_TEMP}}
    entrada = pd.DataFrame([fila], columns=["anio", "mes"] + FEATURES_TEMP)
    return max(0.0, float(_modelo().predict(entrada)[0]))
