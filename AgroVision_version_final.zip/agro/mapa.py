"""Mapa interactivo estilo «mapa de videojuego» (pydeck, ya incluido con Streamlit).

Solo prepara datos y capas visuales: polígonos municipales coloreados, etiquetas con el conteo,
parcelas encima y la cámara (zoom) hacia el municipio elegido. No calcula nada agrícola: los
indicadores son los que devolvió el algoritmo para cada parcela (o los ejemplos ficticios).
"""

from __future__ import annotations

import math
from html import escape

import pandas as pd
import pydeck as pdk

import geo
from contrato import CAMPOS_CLIMA

# Qué pinta cada municipio. Las claves de indicador son las de CAMPOS_CLIMA (se promedian por municipio).
METRICAS = {"parcelas": "Número de parcelas", "hectareas": "Hectáreas activas",
            **{c: f"{v[0]} (promedio)" for c, v in CAMPOS_CLIMA.items()}}
_VERDE = ((38, 95, 70), (150, 225, 160))
RAMPAS = {
    "parcelas": _VERDE, "hectareas": _VERDE,
    "temperatureC": ((254, 224, 144), (215, 48, 39)),
    "rainfallMm": ((170, 205, 240), (30, 100, 200)),
    "soilMoisturePct": ((254, 232, 200), (35, 150, 170)),
    "ndvi": ((230, 245, 150), (20, 140, 80)),
}
ELEVACION = 2200                        # metros que «se levanta» el municipio elegido (exagerado a propósito)
BASE_MUNICIPIO = (28, 52, 44)           # municipio sin datos
MENTA = (199, 244, 161)                 # color de acento (selección)
PALETA_CULTIVOS = [(255, 190, 60), (86, 180, 233), (204, 121, 167), (240, 120, 70), (120, 160, 255),
                   (180, 220, 90), (230, 230, 230), (200, 80, 80), (60, 200, 190), (170, 130, 220), (250, 150, 190)]


# ───────────────────────── DATOS ─────────────────────────
def dataframe(parcelas: list[dict]) -> pd.DataFrame:
    """Parcelas del almacén -> tabla. Cada parcela se ubica en su municipio por COORDENADAS
    (si no cae dentro de Querétaro, se intenta por el nombre escrito)."""
    filas = []
    for p in parcelas:
        clima = (p.get("analisis") or {}).get("climate", {})
        ubicado = geo.municipio_en(p["latitud"], p["longitud"])
        if ubicado is None and geo.clave(p["region"]) == geo.clave(geo.ESTADO):
            ubicado = geo.por_nombre(p["municipio"])
        fila = {
            "id": p["id"], "nombre": p["nombre"], "region": p["region"],
            "municipio": ubicado["nombre"] if ubicado else ((p["municipio"] or "").strip() or "Sin municipio"),
            "mun_cve": ubicado["cve"] if ubicado else None,
            "lat": p["latitud"], "lon": p["longitud"], "cultivo": p["cultivo"],
            "hectareas": p["hectareas"] or 0.0, "activa": bool(p["activa"]), "ejemplo": bool(p["ejemplo"]),
            "analisis_demo": bool(p["analisis_demo"]),
        }
        for campo in CAMPOS_CLIMA:
            valor = clima.get(campo)
            valor = valor.get("value") if isinstance(valor, dict) else valor
            fila[campo] = valor if isinstance(valor, (int, float)) else None
        filas.append(fila)
    columnas = ["id", "nombre", "region", "municipio", "mun_cve", "lat", "lon", "cultivo", "hectareas",
                "activa", "ejemplo", "analisis_demo", *CAMPOS_CLIMA]
    return pd.DataFrame(filas, columns=columnas)


def metricas_municipios(activas: pd.DataFrame) -> pd.DataFrame:
    """Una fila por cada municipio cubierto (geo.ZONA_CVE) (aunque no tengan parcelas)."""
    props = geo.propiedades()
    base = pd.DataFrame({"cve": list(props), "nombre": [p["nombre"] for p in props.values()],
                         "area_km2": [p["area_km2"] for p in props.values()]}).set_index("cve")
    if activas.empty or activas["mun_cve"].notna().sum() == 0:
        agrupado = pd.DataFrame(columns=["parcelas", "hectareas", *CAMPOS_CLIMA])
    else:
        agrupado = activas.dropna(subset=["mun_cve"]).groupby("mun_cve").agg(
            parcelas=("id", "count"), hectareas=("hectareas", "sum"), **{c: (c, "mean") for c in CAMPOS_CLIMA})
    salida = base.join(agrupado)
    salida["parcelas"] = salida["parcelas"].fillna(0).astype(int)
    salida["hectareas"] = salida["hectareas"].fillna(0.0).astype(float).round(1)
    for campo in CAMPOS_CLIMA:
        salida[campo] = pd.to_numeric(salida[campo], errors="coerce")
    return salida


# ───────────────────────── COLORES ─────────────────────────
def _rampa(valor: float | None, minimo: float, maximo: float, metrica: str, alfa: int) -> list[int]:
    if valor is None or pd.isna(valor):
        return [*BASE_MUNICIPIO, alfa]
    t = 0.5 if maximo == minimo else (valor - minimo) / (maximo - minimo)
    claro, oscuro = RAMPAS[metrica]
    return [round(claro[i] + (oscuro[i] - claro[i]) * t) for i in range(3)] + [alfa]


def rango_metrica(metricas: pd.DataFrame, metrica: str) -> tuple[float, float] | None:
    serie = metricas[metrica]
    serie = serie[serie > 0] if metrica in ("parcelas", "hectareas") else serie.dropna()
    return (float(serie.min()), float(serie.max())) if not serie.empty else None


def color_cultivos(cultivos: list[str]) -> dict[str, tuple[int, int, int]]:
    return {c: PALETA_CULTIVOS[i % len(PALETA_CULTIVOS)] for i, c in enumerate(sorted(set(cultivos)))}


# ───────────────────────── CÁMARA ─────────────────────────
def camara(bbox: list[float], inclinar: bool = False, ancho_px: int = 700, alto_px: int = 520) -> pdk.ViewState:
    """Encuadra un rectángulo [minx, miny, maxx, maxy]. Con inclinar=True la cámara se tumba, como en un
    juego de estrategia, para que se aprecie el relieve del municipio elegido."""
    minx, miny, maxx, maxy = bbox
    lat = (miny + maxy) / 2
    zoom_x = math.log2(360 * ancho_px / (512 * max(maxx - minx, 1e-3)))  # el mapa base usa teselas de 512 px
    zoom_y = math.log2(360 * alto_px * math.cos(math.radians(lat)) / (512 * max(maxy - miny, 1e-3)))
    zoom = max(4.0, min(13.0, min(zoom_x, zoom_y) - (0.8 if inclinar else 0.15)))
    vista = pdk.ViewState(latitude=lat, longitude=(minx + maxx) / 2, zoom=zoom,
                          pitch=50 if inclinar else 0, bearing=-18 if inclinar else 0)
    vista.transition_duration = 1100
    return vista


def bbox_estado() -> list[float]:
    cajas = [p["bbox"] for p in geo.propiedades().values()]
    return [min(c[0] for c in cajas), min(c[1] for c in cajas), max(c[2] for c in cajas), max(c[3] for c in cajas)]


# ───────────────────────── CAPAS ─────────────────────────
def construir(activas: pd.DataFrame, metricas: pd.DataFrame, metrica: str, cve_sel: str | None,
              parcela_sel: int | None, mostrar_parcelas: bool,
              estilo: str = "Claro", mostrar_etiquetas: bool = True) -> pdk.Deck:
    rango = rango_metrica(metricas, metrica)
    props = geo.propiedades()

    # 1) Polígonos municipales: relleno por métrica; el elegido brilla y los demás se atenúan.
    features = []
    for f in geo.cargar()["features"]:
        cve = f["properties"]["cve"]
        fila = metricas.loc[cve]
        valor = fila[metrica]
        sin_dato = (valor == 0) if metrica in ("parcelas", "hectareas") else pd.isna(valor)
        alfa = 205 if cve_sel is None else (240 if cve == cve_sel else 80)
        relleno = [*BASE_MUNICIPIO, alfa] if (sin_dato or rango is None) else _rampa(valor, *rango, metrica, alfa)
        elegido = cve == cve_sel
        linea = [*MENTA, 255] if elegido else [*MENTA, 110 if cve_sel else 170]
        t3 = f"{fila['hectareas']:g} ha · ≈{fila['area_km2']:g} km²"
        if metrica not in ("parcelas", "hectareas") and pd.notna(valor):
            t3 += f" · {METRICAS[metrica]}: {valor:.1f}"
        tip = {"t1": fila["nombre"], "t2": f"{int(fila['parcelas'])} parcela(s) activa(s)", "t3": t3,
               "t4": "" if elegido else "Clic para acercarte"}
        features.append({"type": "Feature", "geometry": f["geometry"], "properties": {
            **f["properties"], "relleno": relleno, "linea": linea, "elev": ELEVACION if elegido else 0, **tip}})
    capa_poligonos = pdk.Layer(
        "GeoJsonLayer", {"type": "FeatureCollection", "features": features}, id="municipios_poligonos",
        pickable=True, stroked=True, filled=True, extruded=True, get_elevation="properties.elev",
        get_fill_color="properties.relleno", get_line_color="properties.linea", line_width_min_pixels=1.5,
        transitions={"getElevation": 1100})

    # 2) Etiquetas: nombre y conteo sobre cada municipio.
    etiquetas = pd.DataFrame({
        "lon": [p["lon"] for p in props.values()], "lat": [p["lat"] for p in props.values()],
        "z": [ELEVACION if c == cve_sel else 0 for c in props],  # la etiqueta sube con el terreno
        "nombre": [geo.sin_acentos(p["nombre"]) for p in props.values()],  # el texto del mapa solo dibuja ASCII
        "conteo": [str(int(metricas.loc[c, "parcelas"])) for c in props]})
    capa_nombres = pdk.Layer("TextLayer", etiquetas, id="etiquetas_municipio", pickable=False, get_position="[lon, lat, z]", get_text="nombre", get_size=11,
                             get_color=[235, 245, 238], get_pixel_offset=[0, -11], font_weight=600,
                             background=True, get_background_color=[16, 49, 40, 170], background_padding=[4, 2])
    capa_conteos = pdk.Layer("TextLayer", etiquetas, id="etiquetas_conteo", pickable=False, get_position="[lon, lat, z]", get_text="conteo", get_size=16,
                             get_color=[*MENTA, 255], get_pixel_offset=[0, 9], font_weight=800)
    capas = [capa_poligonos]
    if mostrar_etiquetas:
        capas += [capa_nombres, capa_conteos]

    # 3) Parcelas encima, coloreadas por cultivo (la elegida se agranda).
    if mostrar_parcelas and not activas.empty:
        pts = activas.copy()
        paleta = color_cultivos(list(pts["cultivo"].dropna()))
        pts["color"] = [[*paleta.get(c, (200, 200, 200)), 245] for c in pts["cultivo"]]
        pts["radio"] = [min(900, max(120, math.sqrt(max(h, 0.1)) * 70)) * (2.2 if i == parcela_sel else 1)
                        for i, h in zip(pts["id"], pts["hectareas"])]
        pts["linea"] = [[255, 255, 255, 255] if i == parcela_sel else [16, 49, 40, 220] for i in pts["id"]]
        pts["t1"] = [f"{r.nombre}{' · EJEMPLO' if r.ejemplo else ''}" for r in pts.itertuples()]
        pts["t2"] = [f"{r.cultivo} · {r.hectareas:g} ha" for r in pts.itertuples()]
        pts["t3"] = list(pts["municipio"])
        pts["t4"] = ""
        pts["z"] = [ELEVACION + 40 if c == cve_sel else 0 for c in pts["mun_cve"]]  # sobre la superficie elevada
        capas.append(pdk.Layer(
            "ScatterplotLayer", pts[["id", "lon", "lat", "z", "color", "radio", "linea", "t1", "t2", "t3", "t4"]], id="parcelas",
            get_position="[lon, lat, z]", get_radius="radio", get_fill_color="color", get_line_color="linea",
            stroked=True, line_width_min_pixels=1.5, radius_min_pixels=5, radius_max_pixels=26,
            pickable=True, auto_highlight=True))

    bbox = props[cve_sel]["bbox"] if cve_sel else bbox_estado()
    vista = camara(bbox, inclinar=cve_sel is not None)
    if parcela_sel is not None and not activas.empty:  # se acerca a la parcela elegida (buscador o clic)
        elegida = activas[activas["id"] == parcela_sel]
        if not elegida.empty:
            vista = pdk.ViewState(latitude=float(elegida.iloc[0]["lat"]), longitude=float(elegida.iloc[0]["lon"]),
                                  zoom=12.1, pitch=45, bearing=-18, transition_duration=1100)
    return pdk.Deck(
        layers=capas, initial_view_state=vista, map_provider="carto",
        map_style="light" if estilo == "Claro" else "dark",
        tooltip={"html": "<b>{t1}</b><br/>{t2}<br/>{t3}<br/><i>{t4}</i>", "style": {"backgroundColor": "#103128", "color": "white", "fontSize": "12px",
                                           "border": "1px solid #c7f4a1", "borderRadius": "8px", "padding": "8px 10px"}})


# ───────────────────────── EVENTOS ─────────────────────────
def leer_seleccion(evento: object) -> tuple[str | None, int | None]:
    """Del clic en el mapa -> (clave de municipio, id de parcela). Cualquiera puede ser None."""
    try:
        objetos = evento.selection["objects"]
    except (AttributeError, KeyError, TypeError):
        return None, None
    if objetos.get("parcelas"):
        parcela_id = objetos["parcelas"][0].get("id")
        return None, int(parcela_id) if parcela_id is not None else None
    if objetos.get("municipios_poligonos"):
        objeto = objetos["municipios_poligonos"][0]
        return objeto.get("properties", objeto).get("cve"), None
    return None, None


def leyenda_html(metrica: str, rango: tuple[float, float] | None) -> str:
    if rango is None:
        return '<span style="font-size:12px;color:#5f7367">Sin datos para esta métrica todavía.</span>'
    claro, oscuro = RAMPAS[metrica]
    unidad = CAMPOS_CLIMA[metrica][1] if metrica in CAMPOS_CLIMA else ""
    return (f'<div style="font-size:12px;color:#526b5a;margin-top:6px">{escape(METRICAS[metrica])}: {rango[0]:g} '
            f'<span style="display:inline-block;width:150px;height:10px;border-radius:5px;vertical-align:middle;'
            f'background:linear-gradient(90deg,rgb{claro},rgb{oscuro})"></span> {rango[1]:g} {escape(unidad)}'
            f' &nbsp;·&nbsp; sin color = sin datos</div>')
