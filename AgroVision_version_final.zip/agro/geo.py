"""Geografía municipal de Querétaro (Python puro, sin dependencias extra).

Datos: geo/queretaro_municipios.geojson (18 municipios; se usan solo los de ZONA_CVE; fuente en geo/LEEME.txt).
Sirve para saber en qué municipio cae una coordenada y para dibujar el mapa.
Para otro estado, sustituye el archivo por otro GeoJSON con las mismas propiedades
(cve, nombre, lat, lon, bbox, area_km2).
"""

from __future__ import annotations

import json
import random
import unicodedata
from functools import lru_cache
from pathlib import Path

RUTA = Path(__file__).parent / "geo" / "queretaro_municipios.geojson"
ESTADO = "Querétaro"


def clave(texto: str | None) -> str:
    """Normaliza un nombre: «El Marqués», «el marques » y «EL MARQUES» dan la misma clave."""
    sin_acentos = unicodedata.normalize("NFKD", texto or "").encode("ascii", "ignore").decode()
    return " ".join(sin_acentos.lower().split())


def sin_acentos(texto: str) -> str:
    """Quita acentos conservando mayúsculas (para el texto dibujado en el mapa)."""
    return unicodedata.normalize("NFKD", texto or "").encode("ascii", "ignore").decode()


# La app solo cubre los municipios que tienen estación CONAGUA con datos (carpeta ml/datos):
#   001 Amealco de Bonfil · 002 Pinal de Amoles · 004 Cadereyta de Montes.
# Para añadir otro municipio: pon su archivo mes*.txt en ml/datos/ y agrega aquí su clave.
ZONA_CVE = ("001", "002", "004")


@lru_cache(maxsize=1)
def cargar() -> dict:
    completo = json.loads(RUTA.read_text(encoding="utf-8"))
    completo["features"] = [f for f in completo["features"] if f["properties"]["cve"] in ZONA_CVE]
    return completo


def propiedades() -> dict[str, dict]:
    """cve -> propiedades (nombre, lat, lon, bbox, area_km2)."""
    return {f["properties"]["cve"]: f["properties"] for f in cargar()["features"]}


def _poligonos(geom: dict) -> list:
    return [geom["coordinates"]] if geom["type"] == "Polygon" else geom["coordinates"]


def _en_anillo(lon: float, lat: float, anillo: list) -> bool:
    """Prueba de punto en polígono por trazado de rayo."""
    dentro = False
    j = len(anillo) - 1
    for i in range(len(anillo)):
        xi, yi = anillo[i]
        xj, yj = anillo[j]
        if (yi > lat) != (yj > lat) and lon < (xj - xi) * (lat - yi) / (yj - yi) + xi:
            dentro = not dentro
        j = i
    return dentro


def _en_poligono(lon: float, lat: float, poligono: list) -> bool:
    return _en_anillo(lon, lat, poligono[0]) and not any(_en_anillo(lon, lat, h) for h in poligono[1:])


def municipio_en(lat: float, lon: float) -> dict | None:
    """Propiedades del municipio que contiene la coordenada, o None si cae fuera de Querétaro."""
    for f in cargar()["features"]:
        minx, miny, maxx, maxy = f["properties"]["bbox"]
        if minx <= lon <= maxx and miny <= lat <= maxy:
            if any(_en_poligono(lon, lat, p) for p in _poligonos(f["geometry"])):
                return f["properties"]
    return None


def por_nombre(nombre: str | None) -> dict | None:
    objetivo = clave(nombre)
    return next((p for p in propiedades().values() if clave(p["nombre"]) == objetivo), None) if objetivo else None


def punto_aleatorio(cve: str, azar: random.Random) -> tuple[float, float]:
    """(lat, lon) al azar DENTRO del municipio. Solo se usa para los datos de ejemplo."""
    feature = next(f for f in cargar()["features"] if f["properties"]["cve"] == cve)
    minx, miny, maxx, maxy = feature["properties"]["bbox"]
    for _ in range(500):
        lon, lat = azar.uniform(minx, maxx), azar.uniform(miny, maxy)
        if any(_en_poligono(lon, lat, p) for p in _poligonos(feature["geometry"])):
            return round(lat, 5), round(lon, 5)
    return feature["properties"]["lat"], feature["properties"]["lon"]
