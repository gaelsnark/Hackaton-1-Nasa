@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo      AgroVision - Iniciar aplicacion Streamlit
echo.
set "PYTHON="
where py >nul 2>nul
if %errorlevel%==0 set "PYTHON=py"
if not defined PYTHON (
  where python >nul 2>nul
  if %errorlevel%==0 set "PYTHON=python"
)
if not defined PYTHON (
  echo No se encontro Python. Instalalo desde https://www.python.org/downloads/
  echo y marca la casilla "Add python.exe to PATH".
  pause
  exit /b 1
)
echo Verificando dependencias...
%PYTHON% -m pip install -q -r requirements.txt
if errorlevel 1 (
  echo No se pudieron instalar las dependencias. Revisa tu conexion a internet y Python.
  pause
  exit /b 1
)
%PYTHON% -m streamlit run app.py
pause
