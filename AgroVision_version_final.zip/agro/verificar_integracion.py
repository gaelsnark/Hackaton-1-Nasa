"""Prueba la integración SIN abrir Streamlit.

    python verificar_integracion.py          # usa una parcela de ejemplo
    python verificar_integracion.py --demo   # usa los datos ficticios del frontend

Muestra si analizar_parcela() devuelve algo válido y qué avisos produce.
"""

import json
import sys

from contrato import construir_entrada
from servicio import ejecutar_analisis

PARCELA_EJEMPLO = {
    "nombre": "Parcela de prueba", "region": "Querétaro", "municipio": "Cadereyta de Montes",
    "latitud": 20.79, "longitud": -99.67, "cultivo": "Maíz",
    "cultivos_previos": ["Frijol", "Trigo"], "hectareas": 12.0,
    "tipo_riego": "Temporal (solo lluvia)", "tipo_suelo": None,
    "prioridad": "Ahorrar agua", "periodo_inicio": "2025-11-01", "periodo_fin": "2026-10-31",
    "observaciones": "",
}

if __name__ == "__main__":
    salida = ejecutar_analisis(PARCELA_EJEMPLO, demo="--demo" in sys.argv)
    print("Entrada enviada:\n", json.dumps(construir_entrada(PARCELA_EJEMPLO), indent=2, ensure_ascii=False))
    print(f"\nEstado: {salida.estado}  ({salida.segundos:.2f} s)")
    if salida.estado == "error":
        print(salida.traza)
        sys.exit(1)
    if salida.estado == "sin_algoritmo":
        print("analizar_parcela() devolvió None: el algoritmo aún no está conectado.")
        sys.exit(0)
    for aviso in salida.avisos:
        print("  ⚠", aviso)
    print("\nResultado normalizado:\n", json.dumps(salida.resultado, indent=2, ensure_ascii=False))
    print("\nOK" if not salida.avisos else "\nFunciona, pero revisa los avisos.")
