"""Contrato de datos entre el frontend (Streamlit) y el algoritmo (ML).

Este archivo NO contiene lógica agrícola. Solo define:
  * qué recibe el algoritmo      -> construir_entrada()
  * qué debe devolver            -> normalizar_resultado()
  * cómo se prueban ambos lados  -> resultado_demo() (datos FICTICIOS, claramente marcados)

Así el equipo de ML puede devolver el formato simple (números sueltos) o el
formato completo (valor + unidad + fuente + fecha + incertidumbre) y la
pantalla siempre recibe datos limpios y validados.
"""

from __future__ import annotations

import hashlib
import json
import math
from datetime import date, timedelta
from typing import Any

VERSION_CONTRATO = "1.0"

# clave -> (nombre visible, unidad, mínimo plausible, máximo plausible, decimales)
CAMPOS_CLIMA: dict[str, tuple[str, str, float, float, int]] = {
    "temperatureC": ("Temperatura", "°C", -60.0, 60.0, 1),
    "rainfallMm": ("Precipitación", "mm", 0.0, 10_000.0, 1),
    "soilMoisturePct": ("Humedad del suelo", "%", 0.0, 100.0, 1),
    "ndvi": ("Vigor vegetal (NDVI)", "", -1.0, 1.0, 2),
}

# Límites aproximados de México (para avisar si las coordenadas parecen un error).
MEXICO_LAT = (14.0, 33.0)
MEXICO_LON = (-119.0, -86.0)


# ───────────────────────── ENTRADA (frontend → algoritmo) ─────────────────────────
def construir_entrada(parcela: dict) -> dict:
    """Diccionario JSON-serializable que se envía al algoritmo.

    Campos (todos con tipo simple para poder mandarlos por API sin conversión):
      nombre, region, municipio            str
      latitud, longitud                    float (grados decimales, WGS84)
      cultivo                              str   (cultivo actual)
      cultivos_previos                     list[str] (últimos ciclos, para rotación)
      hectareas                            float
      tipo_riego                           str
      tipo_suelo                           str | None
      prioridad                            str
      periodo_inicio, periodo_fin          str ISO "YYYY-MM-DD"
      observaciones                        str
    """
    datos = dict(parcela)
    datos["schema_version"] = VERSION_CONTRATO
    return datos


def huella(datos: dict) -> str:
    """Identificador estable de una parcela, para saber si cambió desde el último análisis."""
    return hashlib.sha1(json.dumps(datos, sort_keys=True, default=str).encode()).hexdigest()


def coordenadas_fuera_de_mexico(lat: float, lon: float) -> bool:
    return not (MEXICO_LAT[0] <= lat <= MEXICO_LAT[1] and MEXICO_LON[0] <= lon <= MEXICO_LON[1])


# ───────────────────────── SALIDA (algoritmo → frontend) ─────────────────────────
def _numero(valor: Any) -> float | None:
    """Convierte a float finito; None si no es un número válido (bool no cuenta)."""
    if isinstance(valor, bool) or valor is None:
        return None
    try:
        numero = float(valor)
    except (TypeError, ValueError):
        return None
    return numero if math.isfinite(numero) else None


def _texto(valor: Any) -> str | None:
    if valor is None:
        return None
    limpio = str(valor).strip()
    return limpio or None


def _indicador(clave: str, bruto: Any, avisos: list[str]) -> dict:
    """Normaliza un indicador. Acepta un número suelto o un dict con metadatos."""
    nombre, unidad, minimo, maximo, _ = CAMPOS_CLIMA[clave]
    meta = bruto if isinstance(bruto, dict) else {}
    valor = _numero(meta.get("value") if isinstance(bruto, dict) else bruto)

    if bruto is not None and valor is None:
        avisos.append(f"climate.{clave}: el valor no es un número válido ({bruto!r}); se ignora.")
    if valor is not None and not (minimo <= valor <= maximo):
        avisos.append(f"climate.{clave}: {valor} está fuera del rango plausible "
                      f"[{minimo:g}, {maximo:g}] {unidad}; se ignora.")
        valor = None

    incertidumbre = _numero(meta.get("uncertainty"))
    if incertidumbre is not None and incertidumbre < 0:
        avisos.append(f"climate.{clave}: la incertidumbre no puede ser negativa; se ignora.")
        incertidumbre = None

    # Si el valor es real pero faltan metadatos, avisamos (criterio de aceptación #4).
    if valor is not None:
        faltan = [k for k in ("source", "date") if not _texto(meta.get(k))]
        if faltan:
            avisos.append(f"climate.{clave}: falta {' y '.join(faltan)} (se recomienda indicar origen y fecha).")

    return {
        "value": valor,
        "unit": _texto(meta.get("unit")) or unidad,
        "source": _texto(meta.get("source")),
        "date": _texto(meta.get("date")),
        "uncertainty": incertidumbre,
    }


def _serie(bruto: Any, avisos: list[str]) -> list[dict]:
    """series = [{"date": "2026-01", "temperatureC": 18.2, "rainfallMm": 12.0, ...}, ...]"""
    if bruto is None:
        return []
    if not isinstance(bruto, list):
        avisos.append("series: debe ser una lista de registros; se ignora.")
        return []
    filas: list[dict] = []
    for i, fila in enumerate(bruto):
        if not isinstance(fila, dict) or not _texto(fila.get("date")):
            avisos.append(f"series[{i}]: falta 'date'; se omite.")
            continue
        limpia: dict[str, Any] = {"date": _texto(fila["date"])}
        for clave in CAMPOS_CLIMA:
            limpia[clave] = _numero(fila.get(clave))
        if any(limpia[c] is not None for c in CAMPOS_CLIMA):
            filas.append(limpia)
    return filas


def _planes(bruto: Any, avisos: list[str]) -> list[dict]:
    """plans = [{"name", "description", "crops": [...], "score": 0-100 (opcional)}]"""
    if bruto is None:
        return []
    if not isinstance(bruto, list):
        avisos.append("plans: debe ser una lista; se ignora.")
        return []
    planes: list[dict] = []
    for i, plan in enumerate(bruto, start=1):
        if not isinstance(plan, dict):
            avisos.append(f"plans[{i - 1}]: debe ser un diccionario; se omite.")
            continue
        cultivos = plan.get("crops")
        cultivos = [str(c) for c in cultivos if _texto(c)] if isinstance(cultivos, list) else []
        puntaje = _numero(plan.get("score"))
        if puntaje is not None and not 0 <= puntaje <= 100:
            avisos.append(f"plans[{i - 1}].score debe estar entre 0 y 100; se ignora.")
            puntaje = None
        if not _texto(plan.get("name")):
            avisos.append(f"plans[{i - 1}]: falta 'name'; se usa un nombre genérico.")
        planes.append({
            "name": _texto(plan.get("name")) or f"Plan {i}",
            "description": _texto(plan.get("description")) or "Sin descripción.",
            "crops": cultivos,
            "score": puntaje,
        })
    return planes


def normalizar_resultado(bruto: Any) -> tuple[dict | None, list[str]]:
    """Valida lo que devolvió el algoritmo. Devuelve (resultado_limpio, avisos).

    * None  -> el algoritmo aún no está conectado (no es un error).
    * Lo que no sea un diccionario lanza TypeError (la pantalla muestra el error).
    * Nunca inventa valores: lo inválido se descarta y se avisa.
    """
    if bruto is None:
        return None, []
    if not isinstance(bruto, dict):
        raise TypeError(f"El algoritmo debe devolver un diccionario o None, no {type(bruto).__name__}.")

    avisos: list[str] = []
    clima_bruto = bruto.get("climate")
    if clima_bruto is not None and not isinstance(clima_bruto, dict):
        avisos.append("climate: debe ser un diccionario; se ignora.")
        clima_bruto = None
    clima_bruto = clima_bruto or {}
    desconocidas = sorted(set(clima_bruto) - set(CAMPOS_CLIMA))
    if desconocidas:
        avisos.append(f"climate: campos no reconocidos (se ignoran): {', '.join(desconocidas)}.")

    meta = bruto.get("meta") if isinstance(bruto.get("meta"), dict) else {}
    resultado = {
        "climate": {c: _indicador(c, clima_bruto.get(c), avisos) for c in CAMPOS_CLIMA},
        "series": _serie(bruto.get("series"), avisos),
        "recommendation": _texto(bruto.get("recommendation")),
        "plans": _planes(bruto.get("plans"), avisos),
        "meta": {
            "is_demo": bool(meta.get("is_demo", False)),
            "source": _texto(meta.get("source")),
            "generated_at": _texto(meta.get("generated_at")),
            "model_version": _texto(meta.get("model_version")),
        },
    }
    return resultado, avisos


# ───────────────────────── DEMO (datos FICTICIOS, solo para probar la interfaz) ─────────────────────────
def resultado_demo(datos: dict) -> dict:
    """Respuesta inventada a propósito para ver cómo luce la interfaz completa.

    NO es información agrícola real. Va marcada con meta.is_demo=True y la app
    muestra un aviso permanente mientras se use. Solo se activa con el interruptor
    «Modo demostración» de la barra lateral.
    """
    hoy = date.today().replace(day=1)
    meses = [(hoy - timedelta(days=30 * k)).strftime("%Y-%m") for k in range(11, -1, -1)]
    serie = []
    for k, mes in enumerate(meses):
        serie.append({
            "date": mes,
            "temperatureC": round(18 + 5 * math.sin((k - 2) / 12 * 2 * math.pi), 1),
            "rainfallMm": round(max(0.0, 60 + 55 * math.sin((k - 5) / 12 * 2 * math.pi)), 1),
            "soilMoisturePct": round(28 + 8 * math.sin((k - 4) / 12 * 2 * math.pi), 1),
            "ndvi": round(0.45 + 0.2 * math.sin((k - 5) / 12 * 2 * math.pi), 2),
        })
    ultimo = serie[-1]
    etiqueta = {"source": "DEMO (ficticio)", "date": ultimo["date"]}
    return {
        "climate": {
            "temperatureC": {"value": ultimo["temperatureC"], "uncertainty": 0.5, **etiqueta},
            "rainfallMm": {"value": ultimo["rainfallMm"], "uncertainty": 10, **etiqueta},
            "soilMoisturePct": {"value": ultimo["soilMoisturePct"], "uncertainty": 3, **etiqueta},
            "ndvi": {"value": ultimo["ndvi"], "uncertainty": 0.05, **etiqueta},
        },
        "series": serie,
        "recommendation": "TEXTO DE EJEMPLO: aquí el algoritmo explicará su recomendación para "
                          f"«{datos.get('nombre', 'la parcela')}».",
        "plans": [
            {"name": "Plan demo A", "description": "Ejemplo de propuesta de rotación.",
             "crops": ["Cultivo 1", "Cultivo 2", "Cultivo 3"], "score": 82},
            {"name": "Plan demo B", "description": "Segunda alternativa de ejemplo.",
             "crops": ["Cultivo 1", "Cultivo 4"], "score": 74},
            {"name": "Plan demo C", "description": "Tercera alternativa de ejemplo.",
             "crops": ["Cultivo 5", "Cultivo 2"], "score": 61},
        ],
        "meta": {"is_demo": True, "source": "Generado por contrato.resultado_demo()",
                 "generated_at": date.today().isoformat(), "model_version": "demo"},
    }


# Ejemplo del formato COMPLETO esperado (se muestra en la pantalla «Datos NASA»).
EJEMPLO_SALIDA = {
    "climate": {
        "temperatureC": {"value": 0.0, "unit": "°C", "source": "<dataset>", "date": "YYYY-MM-DD", "uncertainty": 0.0},
        "rainfallMm": 0.0,
        "soilMoisturePct": 0.0,
        "ndvi": 0.0,
    },
    "series": [{"date": "YYYY-MM", "temperatureC": 0.0, "rainfallMm": 0.0, "soilMoisturePct": 0.0, "ndvi": 0.0}],
    "recommendation": "Texto para el agricultor",
    "plans": [{"name": "Plan A", "description": "...", "crops": ["..."], "score": 0}],
    "meta": {"source": "<dataset o API>", "generated_at": "YYYY-MM-DD", "model_version": "x.y"},
}
