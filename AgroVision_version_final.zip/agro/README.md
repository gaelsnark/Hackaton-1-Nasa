# AgroVision — versión con datos y modelo conectados

**Zona cubierta:** solo los 3 municipios con estación CONAGUA: Amealco de Bonfil, Pinal de Amoles y Cadereyta de Montes
(`geo.ZONA_CVE`). Para añadir otro: pon su archivo `mes*.txt` en `ml/datos/` y agrega su clave en `geo.ZONA_CVE`.

| Qué | Dónde | De dónde sale |
|---|---|---|
| Lluvia y temperatura mensual | `ml/clima_conagua.py` | `ml/datos/mes*.txt` (CONAGUA) |
| Estimación de lluvia a 3 meses | `ml/clima_conagua.py` + `integracion.py` | `ml/datos/modelo_ajustado_regresion.pkl` (Random Forest del equipo) |
| Humedad del suelo | `ml/nasa_power.py` | NASA POWER (GWETROOT), en vivo o caché `ml/datos/cache_nasa/` |
| Planes de rotación | `ml/rotacion.py` | Clima real de la estación + reglas agronómicas de referencia (tabla `CULTIVOS`) |
| NDVI | — | No conectado (requiere cuenta Earthdata de NASA) |

**Antes de la presentación (con internet):** `py descargar_nasa.py` guarda la humedad del suelo en caché para que funcione sin internet.

**Pendiente / honestidad científica:** los rangos de cada cultivo en `ml/rotacion.py` son valores aproximados, no salen de datos de
cosechas; el modelo Random Forest estima lluvia mensual y se entrenó solo con la estación de Amealco.

---

# AgroVision en Streamlit — solo frontend

Esta es la conversión a **Streamlit** del diseño AgroVision para el reto de agricultura de NASA Space Apps Challenge 2026. Conserva el panel verde y las pantallas, pero usa **Python para construir la interfaz**.

> **No contiene** cálculos agrícolas, respuestas inventadas, llamadas a API de NASA ni lógica de recomendación. Los indicadores y planes muestran `—` o «Pendiente» hasta que el otro equipo conecte su algoritmo.

## Empezar en Windows con VS Code

1. Extrae el ZIP completo.
2. En Visual Studio Code, elige **File → Open Folder** y abre `AgroVision_Streamlit` (la carpeta que contiene `app.py`).
3. En **Terminal → New Terminal**, ejecuta:

   ```powershell
   py -m pip install -r requirements.txt
   ```

   Si `py` no funciona, reemplázalo por `python`.
4. Ejecuta:

   ```powershell
   py -m streamlit run app.py
   ```

5. Streamlit abrirá automáticamente el navegador. Si no lo hace, abre **http://localhost:8501**.
6. Para detenerlo, vuelve a la terminal y presiona `Ctrl + C`.

**Alternativa:** en Windows puedes hacer doble clic en `INICIAR_AGROVISION.bat`, que revisa si Streamlit está instalado y abre la aplicación.

**Importante:** ya no utilices `servidor_demo.py`, `index.html` ni la dirección `localhost:5500` del proyecto anterior.

## ¿Qué se puede probar hoy?

- Navega entre **Panel principal**, **Mi parcela**, **Rotación de cultivos**, **Resultados** y **Datos NASA**.
- Completa **Mi parcela** y presiona **Guardar información**.
- Comprueba que se muestra la información capturada en una tarjeta.
- Ve a **Resultados**: verás la parcela seleccionada y el espacio reservado para indicadores y recomendaciones.
- Pulsa **Analizar parcela**: aparece un mensaje de que falta el algoritmo. Esto es lo esperado.
- Abre **Mapa de parcelas**: carga los *ejemplos ficticios*, haz clic en un municipio para acercarte (ficha con parcelas, cultivos e indicadores) y usa «← Todo Querétaro» para volver. También puedes elegirlo en la lista o en el selector. El mapa base necesita internet.
- Activa **Modo demostración** (barra lateral) para ver la interfaz completa con datos FICTICIOS.

## Archivos

| Archivo | Para qué sirve |
|---|---|
| `app.py` | **Todas las páginas**, navegación, formularios y tarjetas |
| `styles.css` | **Diseño**: colores, fuentes, tarjeta, menú y portada |
| `integracion.py` | **Único archivo que edita el equipo de ML** (función `analizar_parcela`) |
| `mapa.py` / `geo.py` / `almacen.py` | Mapa interactivo (pydeck), geografía municipal y almacén local SQLite de parcelas (`datos/agrovision.db`) |
| `geo/` | Límites de los 18 municipios de Querétaro (GeoJSON simplificado; fuente y licencia dentro) |
| `contrato.py` | Formato de entrada/salida, validación y datos de demostración |
| `servicio.py` | Ejecuta el algoritmo capturando errores |
| `verificar_integracion.py` | Prueba la integración sin abrir Streamlit |
| `.streamlit/config.toml` | Colores básicos que usa Streamlit |
| `requirements.txt` | Librería que debe instalarse |
| `INICIAR_AGROVISION.bat` | Inicio fácil para Windows |
| `GUIA_PASO_A_PASO.md` | Tutorial de los primeros cambios |

## Lo que debes aprender a editar

En `app.py` busca `pantalla_inicio()`. Cambia la frase de la portada dentro de `<h2>` (el HTML aquí solo diseña la sección verde, sin programar algoritmos). Guarda con `Ctrl + S`; Streamlit ofrece actualizar la app.

En `styles.css` busca `--forest: #103128;` y cambia el color para personalizar el menú. Recarga el navegador.

En `app.py` busca `pantalla_parcela()`. Ahí están los campos `st.text_input`, `st.selectbox` y `st.number_input`.

## Cómo conectar el algoritmo al final

El equipo del algoritmo **solo necesita implementar** `analizar_parcela(datos)` en `integracion.py`. La función recibe el diccionario del formulario y devuelve otro diccionario con campos de clima, recomendación y planes. El frontend la llama al pulsar **Analizar parcela**.

La guía detallada del formato está en `INTEGRACION_FUTURA.md`. Si los compañeros trabajan con un servidor/API externo, también se describe esa opción allí.

## Límites del prototipo

- El formulario se conserva durante la sesión; no es una base de datos ni guarda las parcelas permanentemente.
- Los botones de navegación funcionan, pero no hay análisis científico hasta conectar el backend.
- No está publicado en Internet; el enlace `localhost:8501` solo funciona en tu computadora mientras Streamlit está ejecutándose.


## Mapa: efecto "terreno que se levanta"
- `mapa.py`: al elegir un municipio su polígono recibe `elev = ELEVACION` (los demás 0). La capa usa `extruded=True`
  y `transitions` para animar la altura; `camara(inclinar=True)` inclina la vista (pitch/bearing). Para ajustar: `ELEVACION`.
- `app.py`: `elegir_municipio(cve, remontar)` y `mapa_epoca` controlan cuándo se reinicia el mapa; `ultimo_evento`
  evita procesar dos veces el mismo clic.

## Pestaña "Cómo usar"
- `pantalla_tutorial()` en `app.py`: 4 pasos con botones, glosario y preguntas frecuentes. Aviso de bienvenida en el
  inicio (`tutorial_visto`) y ayuda desplegable en el mapa. Todo es texto: se edita directo en esa función.

## Integración con la v1.4 del mapa
Se incorporaron: buscador de parcela (`elegir_parcela`), estilo claro/oscuro, filtro de cultivo, interruptor de nombres,
ayuda sobre el mapa, descarga CSV e `id` en todas las capas (`mapa.construir(..., estilo, mostrar_etiquetas)`).
Se conservó el efecto de terreno elevado, el tutorial y el tooltip con campos simples (t1..t4).
