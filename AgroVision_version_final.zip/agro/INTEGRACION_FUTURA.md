# Integración con el equipo del algoritmo (ML)

**El equipo de ML solo edita `integracion.py`.** El frontend ya valida el formato, captura errores y muestra
los resultados. No hay lógica agrícola ni llamadas a NASA en el resto de la app.

## Cómo probar sin abrir Streamlit

```powershell
py verificar_integracion.py          # llama a analizar_parcela() con una parcela de ejemplo y valida lo que devuelve
py verificar_integracion.py --demo   # igual, pero con los datos FICTICIOS del frontend
```

## Entrada: lo que recibe `analizar_parcela(datos)`

```python
{
  "schema_version": "1.0",
  "nombre": "Parcela Los Pinos", "region": "Querétaro", "municipio": "El Marqués",
  "latitud": 20.58, "longitud": -100.28,          # grados decimales (WGS84)
  "cultivo": "Maíz", "cultivos_previos": ["Frijol", "Trigo"],
  "hectareas": 12.0, "tipo_riego": "Temporal (solo lluvia)",
  "tipo_suelo": None,                              # o "Arcilloso", "Arenoso", ...
  "prioridad": "Ahorrar agua",
  "periodo_inicio": "2025-11-01", "periodo_fin": "2026-10-31",   # ISO, rango de datos a analizar
  "observaciones": ""
}
```

## Salida: lo que debe devolver

Puede devolver el formato **simple** (números sueltos) o el **completo** (recomendado, cumple el criterio 4):

```python
{
  "climate": {
    "temperatureC":    {"value": 21.3, "unit": "°C", "source": "<dataset>", "date": "2026-10-31", "uncertainty": 0.4},
    "rainfallMm":      40.0,          # formato simple también válido
    "soilMoisturePct": 30.0,
    "ndvi":            0.52
  },
  "series": [   # opcional: alimenta las gráficas (una fila por mes/día)
    {"date": "2026-01", "temperatureC": 18.2, "rainfallMm": 12.0, "soilMoisturePct": 25.0, "ndvi": 0.41}
  ],
  "recommendation": "Texto para el agricultor",
  "plans": [    # tantos como quieras; se muestran todos
    {"name": "Plan A", "description": "...", "crops": ["Frijol", "Trigo"], "score": 82}   # score 0-100 opcional
  ],
  "meta": {"source": "<dataset o API>", "generated_at": "2026-11-14", "model_version": "0.1"}
}
```

Reglas de validación (`contrato.py`): rangos plausibles (temperatura −60…60 °C, humedad 0–100 %, NDVI −1…1,
precipitación ≥ 0). Un valor inválido se **descarta y se avisa** (nunca se inventa ni se muestra). Todo campo es opcional.

## Comportamiento de la función

| `analizar_parcela` … | La pantalla muestra |
|---|---|
| devuelve `None` | «Falta conectar el algoritmo» (no es error) |
| devuelve un `dict` | métricas, gráficas, recomendación y planes + avisos de validación |
| lanza una excepción / devuelve otro tipo | mensaje de error + detalle técnico desplegable |

## Dos formas de conectar

**A) Python local** — implementa `_algoritmo_local(datos)` en `integracion.py` (importa tu modelo y llámalo).

**B) API externa** — define la variable de entorno `AGROVISION_API_URL` (y opcional `AGROVISION_API_KEY`):
`integracion.py` hará `POST` con el JSON de entrada y esperará el JSON de salida (timeout 60 s).
En PowerShell: `$env:AGROVISION_API_URL="https://..."; py -m streamlit run app.py`.
**Nunca** pongas claves en el código ni las subas a GitHub.

## Modo demostración

El interruptor «Modo demostración» (barra lateral) llena la interfaz con datos **ficticios** (`contrato.resultado_demo`)
para probar el diseño mientras el algoritmo no está listo. Muestra un aviso permanente. Apágalo para la presentación real.

## Criterios para dar la integración por terminada

1. El formulario guarda los datos correctos (incluye latitud/longitud y periodo).
2. `py verificar_integracion.py` termina en `OK` sin avisos.
3. El botón **Analizar parcela** muestra «ALGORITMO CONECTADO» en la barra superior.
4. **Resultados** muestra métricas con unidad, fuente, fecha e incertidumbre, gráficas y planes.
5. Si el algoritmo falla, la web muestra el error en vez de inventar resultados.
