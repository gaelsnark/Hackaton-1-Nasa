"""Ejecuta el algoritmo de forma segura. El frontend SOLO llama a ejecutar_analisis().

Garantiza que la pantalla nunca se rompa: si el algoritmo falla, tarda de más
o devuelve un formato inválido, se captura el error y se muestra un mensaje.
"""

from __future__ import annotations

import time
import traceback
from dataclasses import dataclass, field

from contrato import construir_entrada, normalizar_resultado, resultado_demo
from integracion import analizar_parcela


@dataclass
class Salida:
    # sin_algoritmo | ok | demo | error
    estado: str
    resultado: dict | None = None
    avisos: list[str] = field(default_factory=list)
    error: str | None = None
    traza: str | None = None
    segundos: float = 0.0


def ejecutar_analisis(parcela: dict, demo: bool = False) -> Salida:
    inicio = time.perf_counter()
    entrada = construir_entrada(parcela)
    try:
        if demo:
            bruto, estado = resultado_demo(entrada), "demo"
        else:
            bruto, estado = analizar_parcela(entrada), "ok"
        resultado, avisos = normalizar_resultado(bruto)
    except Exception as exc:  # noqa: BLE001 - queremos capturar TODO error del algoritmo
        return Salida("error", error=f"{type(exc).__name__}: {exc}",
                      traza=traceback.format_exc(), segundos=time.perf_counter() - inicio)

    if resultado is None:
        return Salida("sin_algoritmo", segundos=time.perf_counter() - inicio)
    return Salida(estado, resultado, avisos, segundos=time.perf_counter() - inicio)
