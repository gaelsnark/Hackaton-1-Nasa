"""Almacén local de parcelas (SQLite, solo librería estándar de Python).

Permite que las parcelas sobrevivan entre sesiones y que el mapa pueda contar
las parcelas activas por municipio. Archivo: datos/agrovision.db
(cámbialo con la variable de entorno AGROVISION_DB).

Aviso: es un prototipo local. Si se despliega en un servicio gratuito (p. ej. Streamlit
Community Cloud) el disco es temporal y los datos pueden perderse al reiniciar.
Para producción conviene una base de datos externa. Las coordenadas son datos
sensibles de personas productoras: obtén su consentimiento antes de mostrarlas públicamente.
"""

from __future__ import annotations

import json
import os
import random
import sqlite3
from contextlib import closing
from datetime import datetime
from pathlib import Path

RUTA = Path(os.getenv("AGROVISION_DB") or Path(__file__).parent / "datos" / "agrovision.db")

_ESQUEMA = """
CREATE TABLE IF NOT EXISTS parcelas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT, region TEXT, municipio TEXT,
    latitud REAL, longitud REAL, cultivo TEXT, hectareas REAL,
    activa INTEGER DEFAULT 1,
    ejemplo INTEGER DEFAULT 0,
    datos TEXT,
    analisis TEXT,
    analisis_demo INTEGER DEFAULT 0,
    creada TEXT, actualizada TEXT
)"""


def _conectar() -> sqlite3.Connection:
    RUTA.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(RUTA)
    con.row_factory = sqlite3.Row
    con.execute(_ESQUEMA)
    return con


def _ahora() -> str:
    return datetime.now().isoformat(timespec="seconds")


def guardar_parcela(parcela: dict, parcela_id: int | None = None, ejemplo: bool = False) -> int:
    """Inserta una parcela nueva, o actualiza la existente si se da parcela_id."""
    campos = (parcela.get("nombre"), parcela.get("region"), parcela.get("municipio") or "",
              parcela.get("latitud"), parcela.get("longitud"), parcela.get("cultivo"),
              parcela.get("hectareas"), json.dumps(parcela, ensure_ascii=False, default=str))
    with closing(_conectar()) as con, con:
        if parcela_id is not None:
            cur = con.execute(
                "UPDATE parcelas SET nombre=?, region=?, municipio=?, latitud=?, longitud=?, cultivo=?, "
                "hectareas=?, datos=?, actualizada=? WHERE id=?", (*campos, _ahora(), parcela_id))
            if cur.rowcount:
                return parcela_id
        cur = con.execute(
            "INSERT INTO parcelas (nombre, region, municipio, latitud, longitud, cultivo, hectareas, datos, "
            "ejemplo, creada, actualizada) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (*campos, int(ejemplo), _ahora(), _ahora()))
        return int(cur.lastrowid)


def guardar_analisis(parcela_id: int, resultado: dict, demo: bool) -> None:
    with closing(_conectar()) as con, con:
        con.execute("UPDATE parcelas SET analisis=?, analisis_demo=?, actualizada=? WHERE id=?",
                    (json.dumps(resultado, ensure_ascii=False), int(demo), _ahora(), parcela_id))


def listar() -> list[dict]:
    with closing(_conectar()) as con:
        filas = [dict(f) for f in con.execute("SELECT * FROM parcelas ORDER BY id")]
    for fila in filas:
        fila["analisis"] = json.loads(fila["analisis"]) if fila["analisis"] else None
        fila.pop("datos", None)
    return filas


def cambiar_activa(parcela_id: int, activa: bool) -> None:
    with closing(_conectar()) as con, con:
        con.execute("UPDATE parcelas SET activa=?, actualizada=? WHERE id=?", (int(activa), _ahora(), parcela_id))


def eliminar(parcela_id: int) -> None:
    with closing(_conectar()) as con, con:
        con.execute("DELETE FROM parcelas WHERE id=?", (parcela_id,))


# ───────────────────── EJEMPLOS FICTICIOS (solo para probar el mapa) ─────────────────────
_CULTIVOS_EJEMPLO = ["Maíz", "Frijol", "Trigo", "Sorgo", "Cebada", "Alfalfa", "Chile"]
# Más parcelas en la zona agrícola del sur/centro y pocas en la sierra (clave INEGI -> peso).
_PESOS_EJEMPLO = {"001": 3, "002": 1, "003": 1, "004": 4, "005": 4, "006": 4, "007": 2, "008": 2, "009": 1,
                  "010": 1, "011": 5, "012": 3, "013": 1, "014": 5, "015": 1, "016": 5, "017": 3, "018": 2}


def cargar_ejemplos(cuantas: int = 60) -> int:
    """Crea parcelas FICTICIAS (marcadas como ejemplo) dentro de los municipios, con indicadores inventados."""
    import geo  # import local: este módulo solo se necesita para los ejemplos

    azar = random.Random(2026)
    props = geo.propiedades()
    claves = [c for c in _PESOS_EJEMPLO if c in props]
    for i in range(cuantas):
        cve = azar.choices(claves, weights=[_PESOS_EJEMPLO[c] for c in claves])[0]
        lat, lon = geo.punto_aleatorio(cve, azar)
        parcela = {
            "nombre": f"Ejemplo {i + 1:02d}", "region": "Querétaro", "municipio": props[cve]["nombre"],
            "latitud": lat, "longitud": lon,
            "cultivo": azar.choice(_CULTIVOS_EJEMPLO), "hectareas": round(azar.uniform(1, 40), 1),
        }
        nuevo_id = guardar_parcela(parcela, ejemplo=True)
        etiqueta = {"source": "EJEMPLO ficticio"}
        analisis = {"climate": {
            "temperatureC": {"value": round(azar.uniform(14, 28), 1), **etiqueta},
            "rainfallMm": {"value": round(azar.uniform(10, 180), 1), **etiqueta},
            "soilMoisturePct": {"value": round(azar.uniform(12, 45), 1), **etiqueta},
            "ndvi": {"value": round(azar.uniform(0.2, 0.8), 2), **etiqueta},
        }}
        guardar_analisis(nuevo_id, analisis, demo=True)
        if azar.random() < 0.12:  # algunas quedan inactivas, para ver la diferencia
            cambiar_activa(nuevo_id, False)
    return cuantas


def borrar_ejemplos() -> None:
    with closing(_conectar()) as con, con:
        con.execute("DELETE FROM parcelas WHERE ejemplo=1")
